@extends('layouts.adminlte')



@section('contenido')
    @can('Administrador')
        @include('profiles.admin.main')
    @endcan

    @can('Alumno')
    @include('profiles.students.main')
    @endcan

    @can('Administrativo')
        @include('profiles.academy.main')
    @endcan

    @can('Docente')
    @include('profiles.teacher.main')
    @endcan
    
@endsection



