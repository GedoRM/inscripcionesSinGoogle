@extends('layouts.adminlte')

@section('css')

@endsection

@section('header')

@endsection

@section('contenido')
    @foreach ($pregunta1 as $item)
        <div class="card m-3 p-3">
            <div class="header">
                <h3>
                    {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                </h3>
            </div>
            <div class="container-fluid">
                <form id="check">
                    <table class="table table-sm">
                        <thead class="text-center">
                            <tr>
                                <th></th>
                                <th>Extremadamente claro</th>
                                <th>Muy claro(a)</th>
                                <th>Moderadamente claro(a)</th>
                                <th>Poco claro(a)</th>
                                <th>No fue claro(a)</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">

                            @foreach ($docenteCurso as $item)
                                <tr>

                                    @csrf
                                    <td>
                                        <p>{{ $item->name }}</p>
                                        <input type="hidden" name="idCurso" id="idCurso" value="{{ $item->idCurso }}">
                                    </td>
                                    @for ($i = 1; $i <= 5; $i++)
                                        <td>
                                            <div id="radios" class="custom-control custom-radio">
                                                <input type="radio" class="radio custom-control-input"
                                                    name="{{ $item->idCurso }}" id="p1{{ $item->idCurso . $i }}"
                                                    value="{{ $i }}">
                                                <label class="custom-control-label"
                                                    for="p1{{ $item->idCurso . $i }}"></label>
                                            </div>
                                        </td>
                                    @endfor
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    @endforeach
    <br><br>
    <div id="res">

    </div>
    <!--
                        @foreach ($pregunta2 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Todos</th>
                                                <th>Muchos</th>
                                                <th>Los suficientes</th>
                                                <th>Pocos</th>
                                                <th>Ninguno</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="p2{{ $item->idCurso . $i }}"
                                                                    name="p2{{ $item->idCurso }}">
                                                                <label class="custom-control-label" for="p2{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach

                        @foreach ($pregunta3 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Casi siempre</th>
                                                <th>Frecuentemente</th>
                                                <th>A veces</th>
                                                <th>Rara vez</th>
                                                <th>Casi nunca</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p3{{ $item->idCurso . $i }}">
                                                                <label class="custom-control-label"
                                                                    for="p3{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach

                        @foreach ($pregunta4 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Extremadamente actuales</th>
                                                <th>Muy actuales</th>
                                                <th>Moderadamente actuales</th>
                                                <th>Poco actuales</th>
                                                <th>Nada actuales</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p4{{ $item->idCurso }}">
                                                                <label class="custom-control-label"
                                                                    for="p4{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach
                        @foreach ($pregunta5 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Demasiado</th>
                                                <th>Mucho</th>
                                                <th>Suficiente</th>
                                                <th>Poco</th>
                                                <th>Nada</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p5{{ $item->idCurso }}">
                                                                <label class="custom-control-label"
                                                                    for="p5{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach
                        @foreach ($pregunta6 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm w-100">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Para nada</th>
                                                <th>Un poco</th>
                                                <th>Algo</th>
                                                <th>Mucho</th>
                                                <th>Una enorme cantidad</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p6{{ $item->idCurso }}">
                                                                <label class="custom-control-label"
                                                                    for="p6{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach
                        @foreach ($pregunta7 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm w-100">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Si</th>
                                                <th>No</th>

                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 2; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p7{{ $item->idCurso }}">
                                                                <label class="custom-control-label"
                                                                    for="p7{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach
                        @foreach ($pregunta8 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Extremadamente</th>
                                                <th>Mucho</th>
                                                <th>Algo</th>
                                                <th>No tanto</th>
                                                <th>Nada</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>

                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="{{ $item->idCurso . $i }}" name="p9{{ $item->idCurso }}">
                                                                <label class="custom-control-label"
                                                                    for="p9{{ $item->idCurso . $i }}"></label>
                                                            </div>
                                                        </td>
                                                    @endfor
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endforeach
                        @foreach ($pregunta9 as $item)
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        {{ $item->idPregunta . '. ' . $item->nombrePregunta }}
                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>

                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            @foreach ($docenteCurso as $item)
                                                <tr>
                                                    <td>
                                                        <p>{{ $item->name }}</p>
                                                    </td>
                                                    <td>
                                                        <textarea name="{{ $item->idCurso . $i }}" id="" cols="30" rows="1"></textarea>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>-->
    </div>
    </div>
    @endforeach

@endsection

@section('js')
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
        
            $('body #radios input').on('click', function() {
                 var valor = $(this).attr('name');
                var value = $(this).attr('value');
                //$(this).attr("name", "radio");
                $.ajax({
                    type: "POST",
                    url: "{{ route('primeraPregunta') }}",
                    data: {
                        value:value,
                        valor:valor,
                        "_token": "{{csrf_token()}}",
                        },
                    success: function(res) {
                        $("#res").html(res);
                     
                        
                    }
                })
            })

        })
    </script>
@endsection
