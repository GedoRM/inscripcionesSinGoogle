@extends('layouts.adminlte')

@section('css')

    <link href="{{ asset('css/styles.css') }}" rel="stylesheet">
@endsection

@section('header')
    <h1 class="m-0 text-dark"><i class="fas fa-file-alt mr-3"></i>Mis documentos</h1>
@endsection

@section('contenido')
    @if (session('sinSeleccionar'))
        <div class="modal pt-5" id="myModal" style="top:20%" tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="text-center">
                            <div class="text-center">
                                <br>
                                <i class="fas fa-exclamation-triangle" style="font-size: 50px; color: red "></i>
                            </div>
                            <br>
                            {{ session('sinSeleccionar') }}
                            <div class="text-center mt-2">
                                <button type="button" class="btn btn-success btn-sm" id="close"
                                    data-dismiss="modal">Ok</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
    @if (session('correcto'))
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('correcto') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @foreach ($student as $date)
        <nav class="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
            <li class="nav-item">
                <a style="color:black" id="datos" href="{{ route('miPerfil', $date->id) }}"
                    class="nav-link">Datos</a>
            </li>
            <li class="nav-item">
                <a href="{{ route('viewDocuments', $date->id) }}" class="nav-link active bg-blue">Documentos</a>
            </li>
        </nav>
        <form action="{{ route('uploadDocuments', $date->id) }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <table class="table p-5">
                        <thead class="text-center">
                            <tr>
                                <th scope="col">
                                    <label>
                                        <p>Nombre del documento</p>
                                    </label>
                                </th>
                                <th scope="col">
                                    <label>
                                        <p>Documento</p>
                                    </label>
                                </th>
                                <th scope="col">
                                    <label>
                                        <p>Descargar</p>
                                    </label>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <label for="acta_nacimiento">
                                        <p>Acta de nacimiento</p>
                                    </label>
                                </td>

                                @if ($date->actaNacimiento != null)
                                    <td>
                                        <input type="file" disabled id="actaNacimiento">

                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->actaNacimiento }}'> {{ $date->actaNacimiento }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="actaNacimiento" id="actaNacimiento">

                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="const_estudio">
                                        <p>Constancia de estudios o Certificado de bachillerato</p>
                                    </label>

                                </td>

                                @if ($date->constanciaEstudios != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->constanciaEstudios }}'>
                                            {{ $date->constanciaEstudios }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="constanciaEstudios" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="curp">
                                        <p>CURP</p>
                                    </label>
                                </td>

                                @if ($date->curp != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->curp }}'> {{ $date->curp }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="curp" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="ine">
                                        <p>INE o credencial escolar</p>
                                    </label>
                                </td>

                                @if ($date->ine != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->ine }}'> {{ $date->ine }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="ine" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="ine_tutor">
                                        <p>INE del tutor</p>
                                    </label>
                                </td>
                                @if ($date->ineTutor != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->ineTutor }}'> {{ $date->ineTutor }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="ineTutor" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="comp_domicilio">
                                        <p>Comprobante de domicilio</p>
                                    </label>
                                </td>

                                @if ($date->comprobanteDomicilio != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->comprobanteDomicilio }}'>
                                            {{ $date->comprobanteDomicilio }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="comprobanteDomicilio" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="foto">
                                        <p>Foto</p>
                                    </label>
                                </td>
                                @if ($date->foto != null)
                                    <td>
                                        <input type="file" disabled id="">
                                    </td>
                                    <td>
                                        <a href='/download/{{ $date->foto }}'> {{ $date->foto }}</a>
                                    </td>
                                @else
                                    <td>
                                        <input type="file" name="foto" id="">
                                    </td>
                                    <td>
                                        <label for="">Ningún archivo cargado</label>
                                    </td>
                                @endif
                            </tr>
                            <tr>
                                <td>
                                    <label for="pago">
                                        <p>Comprobante de pago</p>
                                    </label>
                                </td>
                                
                                @if ($date->comprobantePago != null)
                                <td>
                                    <input type="file" disabled id="">
                                </td>
                                    <td>
                                        <a href='/download/{{ $date->comprobantePago }}'>
                                            {{ $date->comprobantePago }}</a>
                                    </td>
                                @else
                                <td>
                                    <input type="file" name="comprobantePago" id="" value="">
                                </td>
                                <td>
                                    <label for="">Ningún archivo cargado</label>
                                </td>
                                @endif
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-2"></div>

            </div>
            <div class="col-md-12 ">
                <input class="m-auto d-block btn btn-primary" type="submit" value="Subir documento">
            </div>
        </form>
    @endforeach
@endsection

@section('js')
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js">
    </script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.4/js/mdb.min.js"></script>
    <script>
        $("#close").click(function() {
            $("#myModal").modal("hide");
        });
    </script>

    <script type="text/javascript">
        $(function() {
            $("#myModal").modal();
        });
    </script>
    <script>
        $(document).ready(function() {

            $(document).on('click', '.cerrar', function() {
                $('#mensaje').hide();
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            document.getElementById("actaNacimiento").value = "";
        })
    </script>

    <script type="text/javascript">
        $(function() {
            $("#myModal").modal();
        });
    </script>
@endsection
