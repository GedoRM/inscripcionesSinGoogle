<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/login', function () {
    return view('auth/login');
});

Route::get('/', function () {
    
    return view('auth/login');
});

Route::get('/registro', function () {
    $periodo = DB::table('periodos')->where('idPeriodo', '>', '9')->get();
    $programa = DB::table('programa_educativos')->get();
    $modalidad = DB::table('modalidad')->get();
    $municipio = DB::table('municipios')->orderBy('nombreMunicipio', 'ASC')->get();
    
    return view('registro', compact('programa', 'periodo', 'modalidad', 'municipio'));
});


Auth::routes();

Route::get('/Not-found', 'HomeController@no_permitido')->name('Not-found');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/homeStudent', 'HomeController@students')->name('homeStudent');



///////////////////////////////////////////////////////Alumnos/////////////////////////////////////////////////////////////////////////


Route::get('/alumnos/lista_alumnos/', 'StudentController@list_students')->name('list_students')->middleware(['auth', 'checkStatus']);

Route::get('/alumnos/lista_alumnos/acciones/ver/{idAlumno}', 'StudentController@viewInfo')->name('viewInfo')->middleware(['auth', 'checkStatus']);

Route::put('/alumnos/list_alumnos/acciones/update/{idAlumno}', 'StudentController@updateInfo')->name('updateInfo')->middleware(['auth', 'checkStatus']);

Route::get('/alumnos/lista_alumnos/acciones/documents/{idAumno}', [App\Http\Controllers\StudentController::class, 'documents'])->name('documents')->middleware(['auth', 'checkStatus']);

Route::get('/alumnos/lista_alumnos/acciones/recepcion_de_documentos/{idAlumno}', [App\Http\Controllers\StudentController::class, 'receptionDocuments'])->name('reception')->middleware(['auth', 'checkStatus']);

Route::get('/postDownload', [App\Http\Controllers\StudentController::class, 'download'])->name('download')->middleware(['auth', 'checkStatus']);

Route::post('/alumnos/nuevoAlumno', 'FormularioController@newStudent')->name('newStudent');





////////////////////////////////////Aspirantes//////////////////////////////////////////////////////////////////////////////

Route::delete('/aspirantes/delete/{id}', 'StudentController@deleteAspirante')->name('deleteAspirante');


///////////////////////////////////////////////////////Maestros/////////////////////////////////////////////////////////////////////////

Route::get('docentes/lista_docentes', 'TeacherController@list_teacher')->name('list_teacher')->middleware(['auth', 'checkStatus']);

Route::post('docentes/lista_docentes/añadir+nuevo', 'TeacherController@addTeacher')->name('addDocente')->middleware(['auth', 'checkStatus']);

Route::put('docentes/lista_docentes/asignar+usuario/{id}', 'TeacherController@assignUser')->name('docente.assignUser')->middleware(['auth', 'checkStatus']);
///////////////////////////////////////////////////////Materias/////////////////////////////////////////////////////////////////////////

Route::get('materias/lista_materias', 'MateriesController@list_materies')->name('list_materies')->middleware(['auth', 'checkStatus']);

Route::post('/materias/list_materias/añadir+materia', 'MateriesController@addMateries')->name('addMateries')->middleware(['auth', 'checkStatus']);

Route::put('/materias/list_materias/actualizar/{id}', 'MateriesController@UpdateMaterie')->name('update.materie')->middleware(['auth', 'checkStatus']);

////////////////////////////////////////////////////Cursos/////////////////////////////////////////////////////////////////////////////

Route::get('cursos/lista_cursos', 'CourseController@list_course')->name('list_course');

Route::post('cursos/detalle/', 'CourseController@detailMaterie')->name('detailMaterie');

Route::post('curso/nuevoCurso/anadir/', 'CourseController@addCourse')->name('addCourse');

Route::get('curso/{id}/inscribirAlumno', 'CourseController@enrollStudets')->name('enrollStudents');

Route::post('curso/{idCurso}/inscribirAlumno/', 'CourseController@enrolleToCourse')->name('enrolleToCourse');

Route::delete('curso/eliminar/{idCurso}', 'CourseController@eliminarCurso')->name('eliminarCurso');

 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Route::get('login/google', 'Auth\LoginController@redirectToProvider')->name('login.google');
Route::get('login/google/callback', 'Auth\LoginController@handleProviderCallback');

/////////////////////////////////////Perfil - Alumnos ///////////////////////////////////////////////////////////////////////////

Route::get('inicio/miPerfil/{id}', 'ViewStudentController@miPerfil')->name('miPerfil');

Route::get('inicio/miPerfil/verDocumentos/{id}', 'ViewStudentController@viewDocuments')->name('viewDocuments');

Route::post('inicio/miPerfil/cargarDocumento/{id}', 'ViewStudentController@uploadDocuments')->name('uploadDocuments');

Route::get('download/{file}', 'ViewStudentController@download');

Route::put('inicio/miPerfil/{idAlumno}/cartaCompromiso', 'ViewStudentController@updatecCompromiso')->name('updatecCompromiso');

Route::put('/inicio/miPerfil/{idAlumno}/TyC', 'ViewStudentController@updateTyC')->name('updateTyC');

Route::post('{id}/boleta-calificaciones/', 'ViewStudentController@boletaCourse')->name('boleta');

Route::get('{id}/historial-de-pagos', 'ViewStudentController@historialPagos')->name('historialPago');

Route::get('{id}/avanceReticular', 'ViewStudentController@avanceReticular')->name('avanceReticular');

Route::get('{id}/calificaciones-parciales', 'ViewStudentController@calificacionesParciales')->name('calificacionesParciales');

Route::get('{id}/buscar-boleta', 'ViewStudentController@buscarBoleta')->name('buscarBoleta');

Route::get('{id}/evaluacion-docente', 'StudentController@verEvaluacionDocente')->name('verEvaluacionDocente');
////////////////////////////////////Perfil - Docente //////////////////////////////////////////////////////////////////////

Route::get('detalleCurso/{id}', 'ViewTeacherController@detail')->name('detail');

Route::get('curos-asignados/{id}', 'ViewTeacherController@cursosAsignados')->name('cursosAsignados');

Route::get('cursos-asignados/idD={idDocente}/ver-inscritos/{idCurso}', 'ViewTeacherController@inscritosCurso')->name('inscritosCurso');

Route::put('calificarCurso/{idUserCourse}', 'ViewTeacherController@calificar')->name('actualizarCalificacion');

//PERFIL ADMINISTRADOR//

Route::get('cursos_inscrito/{id}', 'AdminController@verCursosActivos')->name('verCursosActivos');

Route::post('cursos_inscrito/{id}', 'AdminController@buscarCursoPorCuatri')->name('buscarCursoPorCuatri');

Route::get('lista_alumnos', 'AdminController@verAlumnos')->name('verAlumnos');

Route::put('lista_aspirantes/{idAlumno}', 'AdminController@actualizarInfo')->name('actualizarInfo');

Route::get('lista_alumnos/{idAlumno}/documentos/', 'AdminController@verDocumentos')->name('documentos');

Route::get('lista_alumnos/{idAlumno}/recepcionDocumentos/', 'AdminController@recepcionDocumentos')->name('recepcionDocumentos');

Route::post('permisoCalificar', 'AdminController@permisoCalificar')->name('permisoCalificar');
/////////////////////////////////////////////////////// Seccion / Usuarios/////////////////////////////////////////////////////////////////////////

Route::get('/usuarios/lista_usuarios', 'AdminController@listaUsuarios')->name('listaUsuarios')->middleware(['auth', 'checkStatus']);

Route::put('/usuarios/lista_usuarios/actualizar_status/{id}', 'AdminController@update_status')->name('usuarios.update_status')->middleware(['auth', 'checkStatus']);

Route::put('/usuarios/lista_usuario/actualizar_rol/{id}', 'AdminController@update_rol')->name('usuarios.update_rol')->middleware(['auth', 'checkStatus']);

Route::delete('/usuarios/delete/{id}', 'AdminController@deleteUser')->name('deleteUser');

//////////////////////////////////////////////////// Seccion / Aspirantes //////////////////////////////////////////////////////////////

Route::get('/aspirantes/lista_aspirantes/', 'AdminController@listaAspirantes')->name('listaAspirantes')->middleware(['auth', 'checkStatus']);

Route::get('/aspirantes/perfil/{idAlumno}', 'AdminController@perfilAspirante')->name('perfilAspirante')->middleware(['auth', 'checkStatus']);


 /////////////////////////////////////////////////// Seccion / Alumnos //////////////////////////////////////////////////////////////////
Route::get('/alumnos/lista_alumnos/acciones/ver/{idAlumno}', 'AdminController@verPerfil')->name('verPerfil')->middleware(['auth', 'checkStatus']);

Route::get('cursos_inscrito/idA={idAlumno}/idC={idCurso}', 'AdminController@calificacionesCursoInscrito')->name('calificacionesCurso');

Route::put('alumnos/lista_alumnos/{id}', 'AdminController@actualizarStatus')->name('actualizarStatus');

/////////////////////////////////////////////////////////////////PDF'S/////////////////////////////////////////////////

Route::post('recepcionDocumentosPDF/{id}', 'PDFController@recepcionDocumentosPDF')->name('recepcionDocumentosPDF');

Route::post('{id}/boletaPDF', 'PDFController@boletaPDF')->name('boletaPDF');

/////////////////////////////////////Perfil - Administrativo/////////////////////////////////////////////////////////////

Route::get('alumnos/lista_alumnos', 'AdministrativeController@viewStudents')->name('academy.viewstudents');

Route::get('alumnos/ver/informacion/{id}','AdministrativeController@viewInfo')->name('academy.infoStudent');

Route::get('alumnos/ver/documentos/{id}', 'AdministrativeController@viewDocuments')->name('academy.viewDocuments');

Route::get('cursos/buscar', 'AdministrativeController@buscar')->name('academy.buscar');

Route::get('pagos/{nombre}/', 'AdministrativeController@pagos')->name('pagos');

Route::post('pagos/{id}/', 'AdministrativeController@addPago')->name('addPago');

Route::post('pagos/actualizar/{idPago}', 'AdministrativeController@actualizarPago')->name('actualizarPago');


//////////////////////////EVALUACION DOCENTE////////////////////////////////////////////////////////////////////////

Route::get('evaluacion-docente/banco-preguntas', 'AdminController@bancoPreguntas')->name('bancoPreguntas');

Route::get('evaluacion-docente/vista-previa', 'AdminController@vistaPrevia')->name('vistaPrevia');

Route::post('evaluacion-docente/primera-pregunta/', 'ViewStudentController@primeraPregunta')->name('primeraPregunta');