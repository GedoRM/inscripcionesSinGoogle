<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cursos extends Model
{
    use HasFactory;

    public function docentes()
    {
        return $this->hasOne('App\Models\User', 'id', 'users');
    }
}
