<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Log;

class TestCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $mes = date("m");
        $anoActual = date("Y");
        $ano = date("Y", strtotime($anoActual."+ 1 year"));
        /*if($mes == 10){
            $updatePeriod = DB::table('permiso_calificars')
            ->update(['permisoCalificar' => "1"]);
        }*/

        $fechaCurso = DB::table('cursos')->get();
        $hoy = date("Y-m-d");
        foreach($fechaCurso as $item){
            $id = $item['idCurso'];
            $fechaFin = $item['fecha_final'];
            $fechaInicio = $item['fecha_inicio'];
            if($hoy < $fechaInicio){
                $updateStatus = DB::table('cursos')
                ->update(['idEstatus' => "4"])->where('idCurso', $id);
            }elseif($hoy = $fechaInicio && $date <= $fechaFinal){
                $updateStatus = DB::table('cursos')
                ->update(['idEstatus' => "2"])->where('idCurso', $id);
            }elseif($hoy > $fechaInicio){
                $updateStatus = DB::table('cursos')
                ->update(['idEstatus' => "3"])->where('idCurso', $id);
            }
            
        }

        dd("Cron ejecutado");

        


    }

}
