<li class="nav-item ml-1">
    <a href=<?php echo e(route('miPerfil', Auth::user()->id)); ?>

        class="nav-link <?php echo e(!Route::is('miPerfil') ?: 'text-primary'); ?>">
        <i class="fas fa-user mr-3"></i>
        <p>
            Mi perfil
        </p>
    </a>
</li>
<li
    class="nav-item has-treeview menu-close <?php echo e(!Route::is('avanceReticular') ?: 'menu-open'); ?> <?php echo e(!Route::is('calificacionesParciales') ?: 'menu-open'); ?>

    <?php echo e(!Route::is('historialPago') ?: 'menu-open'); ?> <?php echo e(!Route::is('buscarBoleta') ?: 'menu-open'); ?>">

    <a href="#" class="nav-link">
        <i class="fas fa-info-circle mr-3"></i>
        <p>
            Información Escolar
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>

    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('avanceReticular', Auth::user()->id)); ?>

                    class="nav-link <?php echo e(!Route::is('avanceReticular') ?: 'text-primary'); ?>">
                    <p>Avance Reticular</p>
                </a>
            </li>
        </ul>
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('calificacionesParciales', Auth::user()->id)); ?>

                    class="nav-link <?php echo e(!Route::is('calificacionesParciales') ?: 'text-primary'); ?>">
                    <p>Calificaciones Parciales</p>
                </a>
            </li>
        </ul>
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('buscarBoleta', Auth::user()->id)); ?>

                    class="nav-link <?php echo e(!Route::is('buscarBoleta') ?: 'text-primary'); ?>">
                    <p>Boletas</p>
                </a>
            </li>
        </ul>
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('historialPago', Auth::user()->id)); ?>

                    class="nav-link <?php echo e(!Route::is('historialPago') ?: 'text-primary'); ?>">
                    <p>Historial de pagos</p>
                </a>
            </li>
        </ul>
    </ul>

</li>
<li class="nav-item ml-1">
    <a href=<?php echo e(route('verEvaluacionDocente', Auth::user()->id)); ?>

        class="nav-link <?php echo e(!Route::is('verEvaluaciondocente') ?: 'text-primary'); ?>">
        <i class="fas fa-clipboard-check mr-3"></i>
        <p>
            Evaluación docente
        </p>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/menu/alumno.blade.php ENDPATH**/ ?>