<table id="oScrol" class="display table table-bordered nowrap" style="width: 100%">
    <thead class="text-center">
        <tr>
            <th colspan="1" rowspan="2">NOMBRE DE LA MATERIA</th>
            <th rowspan="2">CUATRIMESTRE</th>
            <th rowspan="2">CR</th>
            <th colspan="2" class="text-center">Primer parcial </th>
            <th colspan="2" class="text-center">Segundo parcial </th>
            <th colspan="2" class="text-center">Tercer parcial </th>
            <th colspan="2" class="text-center">Calificación final </th>
        </tr>
        <tr>
            <th colspan="1" class="text-center">Calif</th>
            <th colspan="1" class="text-center">Faltas</th>
            <th colspan="1" class="text-center">Calif</th>
            <th colspan="1" class="text-center">Faltas</th>
            <th colspan="1" class="text-center">Calif</th>
            <th colspan="1" class="text-center">Faltas</th>
            <th colspan="1" class="text-center">Número</th>
            <th colspan="1" class="text-center">Letras</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $alumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nombreMateria); ?></td>
                <td class="text-center"><?php echo e($item->numeroCuatrimestre); ?></td>
                <td class="text-center"><?php echo e($item->creditos); ?></td>

                <td><input disabled="true" id="nota1" type="text" maxlength="2" name="nota1"
                        value="<?php echo e($item->nota1); ?>" size="3" class="text-center m-auto d-block" style="border: none" >
                </td>
                <td><input disabled id="falta1" type="text" maxlength="1" name="falta1" value="<?php echo e($item->falta1); ?>"
                        size="3" class="text-center m-auto d-block" style="border: none">
                </td>
                <td><input disabled id="nota2" type="text" maxlength="2" name="nota2" value="<?php echo e($item->nota2); ?>"
                        size="3" class="text-center m-auto d-block" style="border: none">
                </td>
                <td><input disabled id="falta2" type="text" maxlength="1" name="falta2" value="<?php echo e($item->falta2); ?>"
                        size="3" class="text-center m-auto d-block" style="border: none">
                </td>
                <td><input disabled id="nota3" type="text" maxlength="2" name="nota3" value="<?php echo e($item->nota3); ?>"
                        size="3" class="text-center m-auto d-block" style="border: none">
                </td>
                <td><input disabled id="falta3" type="text" maxlength="1" name="falta3" value="<?php echo e($item->falta3); ?>"
                        size="3" class="text-center m-auto d-block" style="border: none">
                </td>
                <td><input disabled id="notaFinal" type="text" maxlength="2" name="final"
                        value="<?php echo e($item->notaFinal); ?>" size="3" class="text-center m-auto d-block"
                        style="border: none"></td>
                <td><input disabled id="textoFinal" type="text" style="width: 200px" name="letras"
                        value="<?php echo e($item->letra); ?>" size="3" class="text-center m-auto d-block" style="border: none">
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>


<?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/estudiantes/acciones/cursoPorCuatri.blade.php ENDPATH**/ ?>