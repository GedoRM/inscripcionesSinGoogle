<li
    class="nav-item has-treeview menu-close <?php echo e(!Route::is('listaUsuarios') ?: 'menu-open'); ?> <?php echo e(!Route::is('listaAspirantes') ?: 'menu-open'); ?>">

    <a href="#" class="nav-link">
        <i class="fas fa-users nav-icon"></i>
        <p>
            Usuarios
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>

    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('listaUsuarios')); ?>

                    class="nav-link <?php echo e(!Route::is('listaUsuarios') ?: 'text-primary'); ?>">
                    <p>Lista de usuarios</p>
                </a>
            </li>
        </ul>
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('listaAspirantes')); ?>

                    class="nav-link <?php echo e(!Route::is('listaAspirantes') ?: 'text-primary'); ?>">
                    <p>Lista de aspirantes</p>
                </a>
            </li>
        </ul>
    </ul>
</li>
<li
    class="nav-item has-treeview menu-close <?php echo e(!Route::is('verAlumnos') ?: 'menu-open'); ?> 
    <?php echo e(!Route::is('verPerfil') ?: 'menu-open'); ?> <?php echo e(!Route::is('documentos') ?: 'menu-open'); ?> <?php echo e(!Route::is('recepcionDocumentos') ?: 'menu-open'); ?>">
    <a href="#" class="nav-link">
        <i class="fas fa-user-graduate nav-icon"></i>
        <p>
            Alumnos
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href="<?php echo e(route('verAlumnos')); ?>"
                    class="nav-link <?php echo e(!Route::is('verAlumnos') ?: 'text-primary'); ?> 
                <?php echo e(!Route::is('verPerfil') ?: 'text-primary'); ?> <?php echo e(!Route::is('documentos') ?: 'text-primary'); ?> <?php echo e(!Route::is('recepcionDocumentos') ?: 'text-primary'); ?> ">
                    <p>Lista de alumnos</p>
                </a>
            </li>
        </ul>
    </ul>
</li>
<li class="nav-item has-treeview menu-close <?php echo e(!Route::is('list_teacher') ?: 'menu-open'); ?>">
    <a href="#" class="nav-link">
        <i class="fas fa-chalkboard-teacher nav-icon"></i>
        <p>
            Profesores
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item">
                <a href="<?php echo e(route('list_teacher')); ?> "
                    class="nav-link <?php echo e(!Route::is('list_teacher') ?: 'text-primary'); ?>">
                    <p>Lista de profesores</p>
                </a>
            </li>
        </ul>
    </ul>
</li>
<li class="nav-item ml-1">
    <a href=<?php echo e(route('list_materies')); ?> class="nav-link <?php echo e(!Route::is('list_materies') ?: 'text-primary'); ?>">
        <i class="fas fa-clipboard-list mr-2"></i>
        <p>
            Materias
        </p>
    </a>
</li>
<li class="nav-item ml-1">
    <a href="<?php echo e(route('list_course')); ?>" class="nav-link <?php echo e(!Route::is('list_course') ?: 'text-primary'); ?>">
        <i class="fas fa-check-circle mr-2"></i>
        <p>
            Cursos
        </p>
    </a>
</li>

<!--<li
    class="nav-item has-treeview menu-close <?php echo e(!Route::is('bancoPreguntas') ?: 'menu-open'); ?> <?php echo e(!Route::is('vistaPrevia') ?: 'menu-open'); ?>">
    <a href="#" class="nav-link">
        <i class="fas fa-clipboard-check mr-2"></i>
        <p>
            Evaluación docente
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item">
                <a href="<?php echo e(route('bancoPreguntas')); ?> "
                    class="nav-link <?php echo e(!Route::is('bancoPreguntas') ?: 'text-primary'); ?>">
                    <p>Banco de preguntas</p>
                </a>
            </li>
        </ul>
        <ul style="list-style-type:none">
            <li class="nav-item">
                <a href="<?php echo e(route('vistaPrevia', ['numero' => '1'])); ?> "
                    class="nav-link <?php echo e(!Route::is('vistaPrevia') ?: 'text-primary'); ?>">
                    <p>Vista previa</p>
                </a>
            </li>
        </ul>
    </ul>
</li>-->
<?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/menu/administrador.blade.php ENDPATH**/ ?>