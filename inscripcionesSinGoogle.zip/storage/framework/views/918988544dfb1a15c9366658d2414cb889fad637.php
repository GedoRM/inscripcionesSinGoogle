

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-users mr-3"></i>Lista de aspirantes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(session('delete')): ?>
<div class="col-md-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('delete')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div> 
<?php endif; ?>
<table id="alumno" class="display table nowrap table-bordered" style="width: 100%"  >
    <thead class="text-center">
        <tr>
            <th>ID</th>
            <th>ASESOR</th>
            <th>NOMBRE (S)</th>
            <th>APELLIDO (S)</th>
            <th>PROGRAMA</th>
            <th>E-MAIL</th>
            <th>FECHA</th>
            <th>ACCIONES</th>
        </tr>
    </thead>
    <tbody class="">
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($id= $students->idAlumno); ?></th>
            <th><?php echo e($students->idAsesores); ?></th>
            <th><?php echo e($students->nombre); ?></th>
            <th><?php echo e($students->apePaterno); ?> <?php echo e($students->apeMaterno); ?> </th>
            <th><?php echo e($students->nombrePrograma); ?></th>
            <th><?php echo e($students->correoAlumno); ?></th>
            <th><?php echo e($students->fechaRegistro); ?></th>
            <th class="text-center">
                <div class="row">
                    <a href="<?php echo e(route('perfilAspirante', $students->idAlumno)); ?>"><button class="ml-3 mr-3 btn btn-warning btn-sm" title="Editar"><i class="fas fa-pen" style="color:white"></i></button></a>
                <form action="<?php echo e(route('deleteAspirante', $students->idAlumno)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" title="Eliminar"><i class="fas fa-trash"></i></button>
                </form>
                </div>
                
            </th>
           </tr>           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/aspirantes/verListaAspirantes.blade.php ENDPATH**/ ?>