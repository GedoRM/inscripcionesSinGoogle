

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="col-md-4 d-block m-auto">
        <form id="cuatri">
            <?php echo csrf_field(); ?>
            <select name="cuatrimestre" class="browser-default custom-select" id="cuatrimestre">
                <option value=" " selected disabled>Seleciona un cuatrimestre</option>
                <?php $__currentLoopData = $cuatrimestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->idCuatrimestre); ?>"><?php echo e($item->numeroCuatrimestre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
    </div>
    <br><br>
    <div class="container">
        <div id="resp">

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $(document).on('ready', function() {
            $("#cuatrimestre").on('change', function() {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('boleta',$id)); ?>",
                    data: $("#cuatri").serialize(),
                    success: function(data) {
                        $("#resp").html(data);
                    }
                });
            }); 
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/buscarBoleta.blade.php ENDPATH**/ ?>