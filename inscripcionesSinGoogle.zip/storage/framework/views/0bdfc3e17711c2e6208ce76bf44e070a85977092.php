<form action="<?php echo e(route('boletaPDF', $id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <table class="table table-bordered border-light table-sm">
        <thead class="table-danger text-center">
            <tr>
                <th>No. de control</th>
                <th>Nombre</th>
                <th>Modalidad</th>
        </thead>
        <tbody class="text-center">
            <?php $__currentLoopData = $datoAlumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($notas->idAlumno); ?></td>
                    <td><?php echo e($notas->nombre); ?> <?php echo e($notas->apePaterno); ?> <?php echo e($notas->apeMaterno); ?></td>
                    <td><?php echo e($notas->nombreModalidad); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tr>
            <thead class="table-danger text-center">
                <tr>
                    <th>Cuatrimestre</th>
                    <th colspan="2">Licenciatura</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr>
                    <?php $__currentLoopData = $datoAlumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($data->numeroCuatrimestre); ?></td>
                        <td colspan="2"><?php echo e($data->nombrePrograma); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>
            </tbody>
        </tr>
    </table>
    <br>

    <table class="table table-bordered table-sm">
        <tr>
            <thead class="table-danger text-center">
                <th>No</th>
                <th>Materia</th>
                <th>Cr</th>
                <th>Calificación</th>
            </thead>
        </tr>
        <tbody>
            <?php
            $creditosCursados = 0;
            $creditosAprobados = 0;
            ?>
            <?php $__currentLoopData = $alumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($item->idMateria); ?></td>
                    <td><?php echo e($item->nombreMateria); ?></td>
                    <input type="hidden" name="cuatrimestre" value="<?php echo e($item->idCuatrimestre); ?>">
                    <td class="text-center"><?php echo e($item->creditos); ?></td>
                    <td class="text-center"><?php echo e($item->notaFinal); ?></td>
                </tr>
                <?php
                $creditosCursados = $creditosCursados + $item->creditos;
                if ($item->notaFinal > 5) {
                    $creditosAprobados = $creditosAprobados + $item->creditos;
                } else {
                    $creditosAprobados = $creditosAprobados + 0;
                }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br><br><br>
    <div class="container">
        <table class="table table-bordered border-light table-sm d-block m-auto" style="width: 50%">
            <thead class="table-danger text-center">
                <tr>
                    <th style="width:2%">CREDITOS CURSADOS</th>
                    <th style="width:2%">CREDITOS APROBADOS</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center"><?php echo e($creditosCursados); ?></td>
                    <td class="text-center"><?php echo e($creditosAprobados); ?></td>
                </tr>
            </tbody>
        </table>
        <br><br><br>
        <div class="text-center">
            <button type="submit" class="btn btn-light" style="border:1px solid rgba(75,75,75,0.3)"><i
                    style="color:black;" class="far fa-file-pdf fa-2x"></i></button>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/boletaCuatrimestre.blade.php ENDPATH**/ ?>