<li class="nav-item has-treeview menu-close <?php echo e(!Route::is('list_students') ?: 'menu-open'); ?> 
    <?php echo e(!Route::is('edit') ?: 'menu-open'); ?> <?php echo e(!Route::is('documents') ?: 'menu-open'); ?> <?php echo e(!Route::is('reception') ?: 'menu-open'); ?>">
    <a href="#" class="nav-link">
        <i class="fas fa-user-graduate nav-icon"></i>
      <p>
        Alumnos
        <i class="right fas fa-angle-left"></i>
      </p>
    </a>
    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item ">
                <a href=<?php echo e(route('academy.viewstudents')); ?> class="nav-link <?php echo e(!Route::is('academy.viewstudents') ?: 'text-primary'); ?> 
                <?php echo e(!Route::is('edit') ?: 'text-primary'); ?> <?php echo e(!Route::is('documents') ?: 'text-primary'); ?> <?php echo e(!Route::is('reception') ?: 'text-primary'); ?> " >
                  <p>Lista de alumnos</p>
                </a>
              </li>
        </ul>
    </ul>
  </li>
  <li class="nav-item has-treeview menu-close <?php echo e(!Route::is('list_teacher') ?: 'menu-open'); ?>">
    <a href="#" class="nav-link">
        <i class="fas fa-chalkboard-teacher nav-icon"></i>
      <p>
        Profesores
        <i class="right fas fa-angle-left"></i>
      </p>
    </a>
    <ul class="nav nav-treeview">
        <ul style="list-style-type:none">
            <li class="nav-item">
            <a href="<?php echo e(route('list_teacher')); ?> " class="nav-link <?php echo e(!Route::is('list_teacher') ?: 'text-primary'); ?>">
                  <p>Lista de profesores</p>
                </a>
              </li>
        </ul>
    </ul>
  </li>
  <li class="nav-item ml-1">
    <a href=<?php echo e(route('list_materies')); ?> class="nav-link">
        <i class="fas fa-clipboard-list mr-2"></i>
      <p>
        Materias
      </p>
    </a>
  </li>
 
  <li class="nav-item ml-1">
    <a href="<?php echo e(route('list_course')); ?>" class="nav-link">
        <i class="fas fa-check-circle mr-2"></i>
      <p>
        Cursos
      </p>
    </a>
  </li>
<?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/menu/administrativo.blade.php ENDPATH**/ ?>