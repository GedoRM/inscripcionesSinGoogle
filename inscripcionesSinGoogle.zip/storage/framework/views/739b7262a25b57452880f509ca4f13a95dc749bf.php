

<?php $__env->startSection('header'); ?>
<h4 class="modal-title w-100 font-weight-bold">Nuevo curso</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php if(session('message')): ?>
<div class="col-md-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('message')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
<form id="firstForm">
    <?php echo csrf_field(); ?>
    <div class="col-md-4">
        <label>Nombre de la materia</label>
        <br>
            <form>
                <select name="materia" class="browser-default custom-select" id="selecMateria" onchange="cambiar(), boton()">
                    <option value="0" selected>Seleciona una materia</option>
                        <?php $__currentLoopData = $materia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->idMateria); ?>" ><?php echo e($item->nombreMateria); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
    </div>  
    <br>
    <div class="col-md-8"></div>
    <div class="col-md-4">
        <div id="recarga2">
           
        </div>
    </div>
    <br>
    <input type="submit" value="Registrar" id="registrar" class="btn btn-success btn-sm" disabled>
    <!--<button type="submit" id="registrar" class="btn btn-success btn-sm" disabled> Registrar</button>-->
    <div id="respuesta">
    </div>
</form>



<?php $__env->stopSection(); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<script>
    function cambiar(){
        $.ajax({
            method: 'POST',
            url: "<?php echo e(route('detailMaterie')); ?>",
            data: $("#firstForm").serialize(),
            beforeSend: function(objeto){
            },
            success:function(data){
                $("#recarga2").html(data);
            }
        });
    }
    
    $(document).ready(function(){
        $("#registrar").click(function(){
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('addCourse')); ?>",
                data: $("#firstForm").serialize(),               
                success:function(res){
                   // $("#respuesta").html(res);
                   
                }
            });
        });
    });

    function boton(){
        var select = document.getElementById('selecMateria').value;
        var boton = document.getElementById('registrar');

        if(select != 0){
            boton.disabled = false;
        }else{
            boton.disabled = true;
        }
    }       

</script>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/course/actions/newCourse.blade.php ENDPATH**/ ?>