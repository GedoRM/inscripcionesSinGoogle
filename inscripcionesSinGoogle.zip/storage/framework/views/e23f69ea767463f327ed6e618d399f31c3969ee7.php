
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="far fa-list-alt mr-3"></i>Lista de cursos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

  <button class="btn btn-success btn-sm" data-target="#modalNewCourse" id="new" data-toggle="modal">
    <i class="fas fa-plus mr-3"></i>Añadir nuevo curso
  </button>
  <?php if(session('existeCurso')): ?>
<div class="col-md-6">
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('existeCurso')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  
</div>
<?php endif; ?>
    <br><br> 

<!--<ul class="nav nav-tabs nav-justified mb-3" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active" data-toggle="tab" href="#escolarizado">Escolarizado</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" data-toggle="tab" href="#mixto">Mixto</a>
  </li>
</ul>-->

<!--<div class="tab-content">
  <div id="escolarizado" class="tab-pane active">-->
    <table id="example" class="display table nowrap table-bordered" style="width: 100%" >
      <thead class="text-center">
          <tr>
              <th>CLAVE DE LA MATERIA</th>
              <th>NOMBRE DE LA MATERIA</th>
              <th>NOMBRE DEL PROFESOR</th>
              <th>ESTATUS</th>
              <th>Alumnos inscritos</th>
              <th>Fecha inicio</th>
              <th>Fecha fin</th>
              <th>ACCIONES</th>
          </tr>
      </thead> 
      <tbody>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th><?php echo e($dato->claveMateria); ?></th>
          <th><?php echo e($dato->nombreMateria); ?></th>
          <th><?php echo e($dato->name); ?></th>
          <th class="text-center"><?php echo e($dato->status); ?></th>
          <th class="text-center"><?php echo e($contador); ?></th>
          <td><?php echo e($dato->fecha_inicio); ?></td>
          <td><?php echo e($dato->fecha_final); ?></td>
          <th class="text-center">
            <a href="#">
              <button class="btn btn-success btn-sm" title="Editar"><i class="fas fa-pen"></i></button>
            </a>
            <a href="<?php echo e(route('enrollStudents', $dato->idCurso)); ?>">
              <button class="btn btn-primary btn-sm" title="Alumnos"><i class="fas fa-users"></i></button>
            </a>
            <a href="#">
              <button class="btn btn-danger btn-sm" title="Eliminar"><i class="fas fa-trash"></i></button>
            </a>
          </th>
        </tr>   
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
  <!--</div>-->
<div class="modal" id="modalNewCourse" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <form id="firstForm" >
      <?php echo csrf_field(); ?>
        <div class="modal-content">
          <div class="modal-header text-center">
            <h4 class="modal-title w-100 font-weight-bold">Añadir nuevo curso</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body mx-3">
            <div class="md-form mb-5">
              <form>
                <label>Nombre de la materia</label>
                <select name="materia" class="browser-default custom-select" id="selecMateria" onchange="cambiar(), boton()">
                  <option value="0" selected>Seleciona una materia</option>
                    <?php $__currentLoopData = $materia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->idMateria); ?>" ><?php echo e($item->nombreMateria); ?></option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </form>
            </div> 
            <div id="recarga2" class="md-form mb-5">
            </div> 
            <div class="md-form mb-5">
              <label>Nombre del docente</label>
              <select name="docente" id="selectDocente" class="browser-default custom-select" disabled>
                <option value="0" selected> Selecciona un docente</option>
                <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($docente->user_id); ?>"><?php echo e($docente->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="row">
              <div class="col-md-6 mb-5">
                <label for="">Fecha de inicio</label>
                <input type="date" name="fecha_inicio" id="fecha_inicio" min="<?php echo e($fecha =date("Y-m-d")); ?>" required disabled>    
              </div>
              <div class="col-md-6 mb-5">
                <label for="">Fecha de fin</label>
                <input type="date" name="fecha_fin" id="fecha_fin" min="<?php echo e($fecha =date("Y-m-d")); ?>" required disabled>    
              </div>
            </div>
            
          </div>
          <div class="modal-footer d-flex justify-content-center">
            <input type="submit" value="Registrar" id="registrar" class="btn btn-success btn-sm" disabled>
          </div>
        </div>
      </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<script>

  
  function cambiar(){
        $.ajax({
            method: 'POST',
            url: "<?php echo e(route('detailMaterie')); ?>",
            data: $("#firstForm").serialize(),
            beforeSend: function(objeto){
            },
            success:function(data){
                $("#recarga2").html(data);
            }
        });
    } 

    function boton(){
        var select = document.getElementById('selecMateria').value;
        var boton = document.getElementById('registrar');
        var docente = document.getElementById('selectDocente');
        var fecha_inicio = document.getElementById('fecha_inicio');
        var fecha_fin = document.getElementById('fecha_fin');

        if(select != 0){
            boton.disabled = false;
            docente.disabled = false;
            fecha_inicio.disabled = false
            fecha_fin.disabled = false;

        }else{
            boton.disabled = true;
            docente.disabled = true;
            fecha_inicio.disabled = true;
            fecha_fin.disabled = true;
        }
    }   

    $(document).ready(function(){
        $("#registrar").click(function(e){
          e.preventDefault();
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('addCourse')); ?>",
                data: $("#firstForm").serialize(),
                success:function(res){
                  $(".alert").show();
                  alert("Curso añadido con éxito!");
                  location.reload();
                  $(".alert").html(res.success);
                } 
            })
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/course/list_course.blade.php ENDPATH**/ ?>