

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-file-signature mr-3"></i>Documentos entregados</h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
    <li class="nav-item">
    <a id="datos" style="color:black" href="<?php echo e(route('viewInfo', $date->idAlumno)); ?>" class="nav-link ">Datos</a>
    </li>
    <li class="nav-item">
    <a style="color:black" href="<?php echo e(route('documents', $date->idAlumno)); ?>" class="nav-link">Documentos</a>
    </li>
    <li class="nav-item">
    <a href="<?php echo e(route('reception', $date->idAlumno)); ?>" id="doc" class="nav-link active bg-blue">Recepción Documentos</a>
    </li>
  </nav>
<br><br>
<div class="container">
    <form class="ml-5" action="<?php echo e(route('recepcionDocumentos',$date->idAlumno)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4 col-12">
                <div class="md-form">
                    <input class="form-control" id="nom" type="text" 
                    value="<?php echo e($date->apePaterno); ?> <?php echo e($date->apeMaterno); ?> <?php echo e($date->nombre); ?>" disabled>
                </div>
                <div class="md-form">
                    <input name="nombreAlumno" value="<?php echo e($date->apePaterno); ?> <?php echo e($date->apeMaterno); ?> <?php echo e($date->nombre); ?>" hidden>
                </div>
            </div>
            <div class="col-md-6 col-12">
            
            </div>
            <div class="col-md-2 col-12">
                <div class="md-form">
                    <input class="form-control" type="datetime" name="fecha" value="<?php echo e(date('d/m/Y')); ?>">
                    <label>Fecha de entrega</label>
                </div>
            </div>
        
        </div>

        <div class="form-row">
            <div class="col-md-4 col-12">
                <div class="md-form">
                    <input class="form-control" id="programa" type="text" value="<?php echo e($date->nombrePrograma); ?>" disabled> 
                    <input name="programa" value="<?php echo e($date->nombrePrograma); ?>" hidden>      
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="md-form">
                    <input class="form-control" id="cuatri" type="number" name="cuatrimestre" min="1" max="9" placeholder="Cuatrimestre" required>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="md-form">
                    <input class="form-control" id="modalidad" type="text" value="<?php echo e($date->nombreModalidad); ?>" disabled>
                    <input name="modalidad" value="<?php echo e($date->nombreModalidad); ?>" hidden>
                </div>
            </div>
        </div>
        <br><br>
        <div class="form-row">
            <div class="col-md-5 col-12">
                <label>DOCUMENTOS:</label>
                
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="acta" name="actaOriginal" value="1" >
                    <label class="custom-control-label" for="acta">
                        Acta de nacimiento (Original)
                    </label>
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="curp" name="curpOriginal" value="1"> 
                    <label class="custom-control-label" for="curp">
                        CURP (Original)
                    </label>
                </div>
                <br>
                <div class="custom-control custom-checkbox">    
                    <input class="custom-control-input" type="checkbox" id="certBachi" name="certificadoOriginal" value="1"> 
                    <label class="custom-control-label" for="certBachi">
                        Certificado de Bachillerato (Original)
                    </label>
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="consEstud" name="constanciaOriginal" value="1"> 
                    <label class="custom-control-label" for="consEstud">
                        Constancia de estudio
                    </label>
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="foto" name="fotoOriginal" value="1">
                    <label class="custom-control-label" for="foto">
                        Fotografías (4)
                    </label>
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="ineAlum" name="ineAlumnoOriginal" value="1"> 
                    <label class="custom-control-label" for="ineAlum">
                        INE del alumno (Copia)
                    </label>    
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="ine_tu" name="ineTutorOriginal" value="1">
                    <label class="custom-control-label" for="ine_tu">
                        INE del padre/tutor (Copia)
                    </label> 
                </div>
                <br>
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="comprobante_d" name="comprobanteOriginal" value="1"> 
                    <label class="custom-control-label" for="comprobante_d">
                        Comprobante de Domicilio
                    </label>
                </div>
            </div>
            <div class="col-md-5 col-12">
                <label>Observaciones:</label>
                <div class="md-form">
                    <textarea name="observaciones" id="obs" rows="12" cols="50"> </textarea>
                </div>
            </div>
        </div>
        <br><br>
        <div class="row">
            <div class="col-md-6 text-center">
                <input class="form-control text-center" type="text" style="border: none;" name="recibe" value="<?php echo e(Auth::user()->name); ?>"disabled >
                <input name="recibe" value="<?php echo e(Auth::user()->name); ?>" hidden >
                
                <hr>
                <label><b>Recibe</b></label>
            </div>
            <div class="col-md-6 text-center">
                <input class="form-control text-center" type="text"  name="entrega" 
                    value="<?php echo e($date->apePaterno); ?> <?php echo e($date->apeMaterno); ?> <?php echo e($date->nombre); ?>" style="border: none; " disabled>
                    <input name="entrega" value="<?php echo e($date->apePaterno); ?> <?php echo e($date->apeMaterno); ?> <?php echo e($date->nombre); ?>" hidden>
                <hr>
                <label><b>Entrega</b></label>
            </div>
        </div>
        <br><br>
        <div class="col-md-12 text-center">
            <button type="submit" class="btn btn-primary btn-sm" name="enviar">
                <i class="fas fa-download mr-3"></i>
                    Generar PDF
            </button>
        </div>          
    </form>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/students/actions/reception_documents.blade.php ENDPATH**/ ?>