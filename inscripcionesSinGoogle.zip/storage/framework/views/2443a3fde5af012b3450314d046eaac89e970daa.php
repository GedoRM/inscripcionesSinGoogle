

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        #head{
            font-weight: 600;
            border-bottom: 2px solid;
            border-bottom-color: #d23907;  
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <table class="table text-center table-striped">
        <thead>
            <th id="head">Concepto</th>
            <th id="head">Cantidad</th>
            <th id="head">Estatus</th>
            <th id="head">Fecha</th>
            <th id="head">Descripcion</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $verPagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nombreConcepto); ?></td>
                <td>MXN $<?php echo e($item->cantidad); ?></td>

                <?php if($item->estatusPago == "Pagado"): ?>
                <td style="color:green; font-weight:bold"><?php echo e($item->estatusPago); ?></td>
                <?php else: ?>
                <td style="color:orange; font-weight:bold"><?php echo e($item->estatusPago); ?></td>
                <?php endif; ?>
                
                <td><?php echo e($item->fechaCaptura); ?></td>
                <td><?php echo e($item->descripcion); ?></td>      
            </tr>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/historialPago.blade.php ENDPATH**/ ?>