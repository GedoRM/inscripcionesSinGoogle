

<?php $__env->startSection('header'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <table class="table table-bordered border-light table-sm" >
        <thead class="table-danger text-center">
            <tr>
                <th>No. de control</th>
                <th>Nombre</th>
                <th>Modalidad</th>
        </thead>
        <tbody class="text-center">
            <?php $__currentLoopData = $datoAlumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td>12470484</td>
                <td><?php echo e($notas->nombre); ?> <?php echo e($notas->apePaterno); ?> <?php echo e($notas->apeMaterno); ?></td>
                <td><?php echo e($notas->nombreModalidad); ?></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
            <tr>
                <thead class="table-danger text-center">
                    <tr>
                        <th>Cuatrimestre</th>
                        <th colspan="2">Licenciatura</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <tr>
                        <?php $__currentLoopData = $datoAlumnoCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($data->numeroCuatrimestre); ?></td>
                            <td colspan="2"><?php echo e($data->nombrePrograma); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tr>
                </tbody>
            </tr>
    </table>
    <br>
    
    <table class="table table-bordered table-sm">
        <tr>
            <thead class="table-danger text-center">
                <th>No</th>
                <th>Materia</th>
                <th>Cr</th>
                <th>Calificación</th>
            </thead>
        </tr>
            <tbody>
                <?php $__currentLoopData = $courseStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($data->idMateria); ?></td>
                    <td ><?php echo e($data->nombreMateria); ?></td>
                    <td class="text-center"><?php echo e($data->creditos); ?></td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/profiles/students/califCourse.blade.php ENDPATH**/ ?>