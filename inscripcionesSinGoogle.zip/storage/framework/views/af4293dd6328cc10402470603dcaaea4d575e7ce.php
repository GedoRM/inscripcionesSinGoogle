

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="m-0 text-dark"><i class="fas fa-users mr-3"></i>Lista de usuarios</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

    <?php if(session('status_update')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('status_update')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('rol_update')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('rol_update')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('delete')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('delete')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('noDelete')): ?>
        <div class="col-md-6">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('noDelete')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <table id="example" class="display table nowrap table-bordered" style="width: 100%">
        <thead class="text-center">
            <tr>
                <th>ID</th>
                <th>NOMBRE</th>
                <th>E-MAIL</th>
                <th>ROL</th>
                <th>STATUS</th>
                <td>ACCIONES</td>


            </tr>
        </thead>
        <tbody class="text-center">
            <?php $__currentLoopData = $rol_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><a href="" data-toggle="modal"
                            data-target="#modalRolChange<?php echo e($item->id); ?>"><?php echo e($item->name_rol); ?></a>
                        <div class="modal fade" id="modalRolChange<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('usuarios.update_rol', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="modal-header text-center">
                                            <h4 class="modal-title w-100 font-weight-bold text-wrap">Cambiar Rol de
                                                <?php echo e($item->name); ?></h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body mx-3">
                                            <div class="md-form mb-5">
                                                <label data-error="wrong" data-success="right"
                                                    for="orangeForm-name">Selecciona un rol</label><br>
                                                <select class="browser-default custom-select" name="roles" id="">
                                                    <?php $__currentLoopData = $list_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($roles->id); ?>"> <?php echo e($roles->name_rol); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <input type="text" name="email" value="<?php echo e($item->email); ?>"
                                                    style="display: none">
                                            </div>
                                        </div>
                                        <div class="modal-footer d-flex justify-content-center">
                                            <button type="submit" class="btn btn-success">Guardar cambios</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td><a href="" data-toggle="modal"
                            data-target="#modalStatusChange<?php echo e($item->id); ?>"><?php echo e($item->status); ?></a>
                        <div class="modal fade" id="modalStatusChange<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <form action=<?php echo e(route('usuarios.update_status', $item->id)); ?> method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="modal-header text-center">
                                            <h4 class="modal-title w-100 font-weight-bold text-wrap">Cambiar Estatus de
                                                <?php echo e($item->name); ?></h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body mx-3">
                                            <div class="md-form mb-5">
                                                <label data-error="wrong" data-success="right"
                                                    for="orangeForm-name">Selecciona un status</label><br>
                                                <select class="browser-default custom-select" name="id_status" id="">
                                                    <?php $__currentLoopData = $list_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($status->id); ?>"> <?php echo e($status->status); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="modal-footer d-flex justify-content-center">
                                            <button type="submit" class="btn btn-success btn-sm">Guardar cambios</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <a href="" class="btn btn-danger btn-sm" data-toggle="modal"
                            data-target="#modalDelete<?php echo e($item->id); ?>"><i class="fas fa-trash-alt"></i></a>
                        <div class="modal fade" id="modalDelete<?php echo e($item->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header" style="display: block; margin:auto">
                                        <i class="fas fa-exclamation-circle" style="font-size: 50px; color: red "></i>
                                        <br><br>
                                        <h5 class="modal-title" id="exampleModalLabel">¿Desea eliminar este usuario?</h5>
                                    </div>
                                    <div class="modal-footer text-center d-block m-auto">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <form action="<?php echo e(route('deleteUser', $item->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-success" data-mdb-dismiss="modal">
                                                        Aceptar
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="col-md-6">
                                                <button type="button" data-dismiss="modal" aria-label="Close"
                                                    class="btn btn-secondary">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/usuarios/verListausuarios.blade.php ENDPATH**/ ?>