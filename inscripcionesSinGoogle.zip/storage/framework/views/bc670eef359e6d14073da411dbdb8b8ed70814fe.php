

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php $__currentLoopData = $pregunta1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card m-3 p-3">
            <div class="header">
                <h3>
                    <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                </h3>
            </div>
            <div class="container-fluid">
                <form id="check">
                    <table class="table table-sm">
                        <thead class="text-center">
                            <tr>
                                <th></th>
                                <th>Extremadamente claro</th>
                                <th>Muy claro(a)</th>
                                <th>Moderadamente claro(a)</th>
                                <th>Poco claro(a)</th>
                                <th>No fue claro(a)</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">

                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <?php echo csrf_field(); ?>
                                    <td>
                                        <p><?php echo e($item->name); ?></p>
                                        <input type="hidden" name="idCurso" id="idCurso" value="<?php echo e($item->idCurso); ?>">
                                    </td>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <td>
                                            <div id="radios" class="custom-control custom-radio">
                                                <input type="radio" class="radio custom-control-input"
                                                    name="<?php echo e($item->idCurso); ?>" id="p1<?php echo e($item->idCurso . $i); ?>"
                                                    value="<?php echo e($i); ?>">
                                                <label class="custom-control-label"
                                                    for="p1<?php echo e($item->idCurso . $i); ?>"></label>
                                            </div>
                                        </td>
                                    <?php endfor; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br><br>
    <div id="res">

    </div>
    <!--
                        <?php $__currentLoopData = $pregunta2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Todos</th>
                                                <th>Muchos</th>
                                                <th>Los suficientes</th>
                                                <th>Pocos</th>
                                                <th>Ninguno</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="p2<?php echo e($item->idCurso . $i); ?>"
                                                                    name="p2<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label" for="p2<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $pregunta3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Casi siempre</th>
                                                <th>Frecuentemente</th>
                                                <th>A veces</th>
                                                <th>Rara vez</th>
                                                <th>Casi nunca</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p3<?php echo e($item->idCurso . $i); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p3<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $pregunta4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Extremadamente actuales</th>
                                                <th>Muy actuales</th>
                                                <th>Moderadamente actuales</th>
                                                <th>Poco actuales</th>
                                                <th>Nada actuales</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p4<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p4<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pregunta5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Demasiado</th>
                                                <th>Mucho</th>
                                                <th>Suficiente</th>
                                                <th>Poco</th>
                                                <th>Nada</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p5<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p5<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pregunta6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm w-100">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Para nada</th>
                                                <th>Un poco</th>
                                                <th>Algo</th>
                                                <th>Mucho</th>
                                                <th>Una enorme cantidad</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p6<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p6<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pregunta7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm w-100">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Si</th>
                                                <th>No</th>

                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 2; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p7<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p7<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pregunta8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>
                                                <th>Extremadamente</th>
                                                <th>Mucho</th>
                                                <th>Algo</th>
                                                <th>No tanto</th>
                                                <th>Nada</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>

                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <td>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input"
                                                                    id="<?php echo e($item->idCurso . $i); ?>" name="p9<?php echo e($item->idCurso); ?>">
                                                                <label class="custom-control-label"
                                                                    for="p9<?php echo e($item->idCurso . $i); ?>"></label>
                                                            </div>
                                                        </td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pregunta9; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card m-3 p-3">
                                <div class="header">
                                    <h3>
                                        <?php echo e($item->idPregunta . '. ' . $item->nombrePregunta); ?>

                                    </h3>
                                </div>
                                <div class="container-fluid">
                                    <table class="table table-sm">
                                        <thead class="text-center">
                                            <tr>
                                                <th></th>

                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__currentLoopData = $docenteCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <p><?php echo e($item->name); ?></p>
                                                    </td>
                                                    <td>
                                                        <textarea name="<?php echo e($item->idCurso . $i); ?>" id="" cols="30" rows="1"></textarea>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>-->
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
        
            $('body #radios input').on('click', function() {
                 var valor = $(this).attr('name');
                var value = $(this).attr('value');
                 console.log(idCurso);
                //$(this).attr("name", "radio");
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('primeraPregunta')); ?>",
                    data: {
                        value:value,
                        valor:valor,
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    success: function(res) {
                        $("#res").html(res);
                     
                        
                    }
                })
            })

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/evaluacionDocente.blade.php ENDPATH**/ ?>