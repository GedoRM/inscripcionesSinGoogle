

<?php $__env->startSection('css'); ?>

<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="m-0 text-dark"><i class="fas fa-file-alt mr-3"></i>Documentos del alumno</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php if(session('sinSeleccionar')): ?>
    <div class="col-md-6">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('sinSeleccionar')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
<?php endif; ?>
<?php if(session('correcto')): ?>
    <div class="col-md-6">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('correcto')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
<?php endif; ?>
<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
    <li class="nav-item">
    <a style="color:black" id="datos" href="<?php echo e(route('miPerfil', $date->id)); ?>" class="nav-link">Datos</a>
    </li>
    <li class="nav-item">
    <a  href="<?php echo e(route('viewDocuments', $date->id)); ?>" class="nav-link active bg-blue">Documentos</a>
    </li>
  </nav>
<form action="<?php echo e(route('uploadDocuments', $date->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <table class="table p-5">
            <thead>
                <tr>
                    <th scope="col">
                        <label><p>Nombre del documento</p></label>
                    </th>
                    <th scope="col">
                        <label><p>Documento</p></label>
                    </th>
                    <th scope="col">
                        <label><p>Descargar</p></label>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <label for="acta_nacimiento"><p>Acta de nacimiento</p></label>
                    </td>
                    <td>
                        <input type="file" name="actaNacimiento" id="">
                        
                    </td>
                    <?php if($date->actaNacimiento != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->actaNacimiento); ?>'> <?php echo e($date->actaNacimiento); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="const_estudio"><p>Constancia de estudios o Certificado de bachillerato</p></label>
                        
                    </td>
                    <td>
                        <input type="file" name="constanciaEstudios" id="">
                    </td>
                    <?php if($date->constanciaEstudios != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->constanciaEstudios); ?>'> <?php echo e($date->constanciaEstudios); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="curp"><p>CURP</p></label>
                    </td>
                    <td>
                        <input type="file" name="curp" id="">
                    </td>
                    <?php if($date->curp != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->curp); ?>'> <?php echo e($date->curp); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td> 
                        <label for="ine"><p>INE o credencial escolar</p></label>
                    </td>
                    <td>
                        <input type="file" name="ine" id="">
                    </td>
                    <?php if($date->ine != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->ine); ?>'> <?php echo e($date->ine); ?></a>
                        </td>
                    <?php endif; ?> 
                </tr>
                <tr>
                    <td>
                        <label for="ine_tutor"><p>INE del tutor</p></label>
                    </td>
                    <td>
                        <input type="file" name="ineTutor" id="">
                    </td>
                    <?php if($date->ineTutor != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->ineTutor); ?>'> <?php echo e($date->ineTutor); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="comp_domicilio"><p>Comprobante de domicilio</p></label>
                    </td>
                    <td>
                        <input type="file" name="comprobanteDomicilio" id="">
                    </td>
                    <?php if($date->comprobanteDomicilio != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->comprobanteDomicilio); ?>'> <?php echo e($date->comprobanteDomicilio); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="foto"><p>Foto</p></label>
                    </td>
                    <td>
                        <input type="file" name="foto" id="">
                    </td>
                    <?php if($date->foto != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->foto); ?>'> <?php echo e($date->foto); ?></a>
                        </td>
                    <?php endif; ?>               
                </tr>
                <tr>
                    <td>
                        <label for="pago"><p>Comprobante de pago</p></label>
                    </td>
                    <td>
                        <input type="file" name="comprobantePago" id="" value="">
                    </td>
                    <?php if($date->comprobantePago != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->comprobantePago); ?>'> <?php echo e($date->comprobantePago); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="col-md-2"></div>

</div>
<div class="col-md-12 ">
    <input class="m-auto d-block btn btn-primary" type="submit" value="Subir documento">
</div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.4/js/mdb.min.js"></script>
<script>
    $("#close").click(function(){
      $("#myModal").modal("hide");
  });
</script>

<script type="text/javascript">
    $(function(){
     $("#myModal").modal();
    });
   </script>
   <script>
    $(document).ready(function(){
    
      $(document).on('click', '.cerrar', function () {
        $('#mensaje').hide();
      });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/profiles/students/documents.blade.php ENDPATH**/ ?>