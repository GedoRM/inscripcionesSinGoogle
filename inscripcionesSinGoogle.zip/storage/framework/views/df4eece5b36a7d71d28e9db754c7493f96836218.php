<?php echo $__env->yieldContent('menuStudent'); ?>
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
    <li class="nav-item">
    <a id="datos" href="<?php echo e(route('viewInfo', $date->idAlumno)); ?>" class="nav-link active bg-blue">Datos</a>
    </li>
    <li class="nav-item">
    <a style="color:black" href="<?php echo e(route('documents', $date->idAlumno)); ?>" class="nav-link">Documentos</a>
    </li>
    <li class="nav-item">
    <a style="color:black; " href="#" id="doc" class="nav-link">Recepción Documentos</a>
    </li>
  </nav>    
<?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/layouts/menuStudents.blade.php ENDPATH**/ ?>