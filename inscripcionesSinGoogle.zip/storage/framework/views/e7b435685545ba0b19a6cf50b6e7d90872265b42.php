

<?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><i class="fas fa-money-bill-alt mr-2"></i> Registro de pagos de
            <strong><?php echo e($item->nombre . ' ' . $item->apePaterno . ' ' . $item->apeMaterno); ?> </strong>
        </h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <style>
        #head {
            font-weight: 600;
            border-bottom: 2px solid;
            border-bottom-color: #d23907;
        }

        input.descripcion {
            text-transform: capitalize;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensaje')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('mensaje')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('pagoActualizado')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('pagoActualizado')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalRegistroPago">
        Registrar pago
    </button>
    <!-- Modal -->
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="modal fade" id="modalRegistroPago" tabindex="-1" aria-labelledby="modalRegistroPago"
            aria-hidden="true">
            <div class="modal-dialog">
                <form action="<?php echo e(route('addPago', $item->idAlumno)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header ">
                            <h5 class="moda-title" id="modalRegistroPago">Registrar nuevo pago</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-body mx-3 text-left">
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Concepto</label>
                                    <select name="concepto" id="" class="browser-default custom-select">
                                        <option value="" disabled selected>Selecciona un concepto de pago</option>
                                        <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->idConcepto); ?>"><?php echo e($item->nombreConcepto); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Cantidad</label>
                                    <input type="text" class="form-control validate" name="cantidad" placeholder="$">
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Estatus</label>
                                    <select name="estatus" id="" class="browser-default custom-select">
                                        <option value="" disabled selected>Selecciona un estatus de pago</option>
                                        <?php $__currentLoopData = $estatusPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->idEstatusPago); ?>"><?php echo e($item->estatusPago); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Descripcion</label>
                                    <input type="text" class="form-control validate descripcion" name="descripcion">
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                Cancelar
                            </button>
                            <button type="submit" class="btn btn-success">Registrar pago</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th id="head">Concepto</th>
                <th id="head">Cantidad</th>
                <th id="head">Estatus</th>
                <th id="head">Fecha</th>
                <th id="head">Descripcion</th>
                <th id="head">Acciones</th>
            </tr>

        </thead>
        <tbody>
            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($registro->nombreConcepto); ?></td>
                    <td>MXN $<?php echo e($registro->cantidad); ?></td>
                    <?php if($registro->estatusPago == 'Pendiente'): ?>
                        <td style="color: orange"><?php echo e($registro->estatusPago); ?></td>
                    <?php elseif($registro->estatusPago == "Pagado"): ?>
                        <td style="color: green"><?php echo e($registro->estatusPago); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($registro->fechaCaptura); ?></td>
                    <td><?php echo e($registro->descripcion); ?></td>
                    <td><button class="btn btn-primary" title="Editar" data-toggle="modal"
                            data-target="#editarPago<?php echo e($idPago = $registro->idPago); ?>"><i
                                class="fas fa-edit"></i></button>
                    </td>
                </tr>
                <div class="modal fade" id="editarPago<?php echo e($idPago); ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <form action="<?php echo e(route('actualizarPago', $idPago)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Editar pago</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body mx-3 text-left">
                                        <div class="md-form mb-5">
                                            <label data-error="wrong" data-success="right">Concepto</label>
                                            <select name="concepto" id="" class="browser-default custom-select">
                                                <option value="<?php echo e($registro->idConcepto); ?>">
                                                    <?php echo e($registro->nombreConcepto); ?></option>
                                                <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->idConcepto); ?>">
                                                        <?php echo e($item->nombreConcepto); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="md-form mb-5">
                                            <label data-error="wrong" data-success="right">Cantidad</label>
                                            <input type="text" class="form-control validate" name="cantidad"
                                                value="<?php echo e($registro->cantidad); ?>">
                                        </div>
                                        <div class="md-form mb-5">
                                            <label data-error="wrong" data-success="right">Estatus</label>
                                            <select name="estatus" id="" class="browser-default custom-select">
                                                <option value="<?php echo e($registro->idEstatusPago); ?>">
                                                    <?php echo e($registro->estatusPago); ?>

                                                </option>
                                                <?php $__currentLoopData = $estatusPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->idEstatusPago); ?>">
                                                        <?php echo e($item->estatusPago); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="md-form mb-5">
                                            <label data-error="wrong" data-success="right">Descripcion</label>
                                            <input type="text" class="form-control validate descripcion" name="descripcion"
                                                value="<?php echo e($registro->descripcion); ?>">
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                        Cancelar
                                    </button>
                                    <button type="submit" class="btn btn-success">Actualizar pago</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/academy/students/verPagos.blade.php ENDPATH**/ ?>