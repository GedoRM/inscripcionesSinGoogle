

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h3><i class="far fa-list-alt mr-3"></i>Calificaciones parciales</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <table class="table table-sm table-bordered nowrap">

            <thead>
                <tr>
                    <th rowspan="2" class="text-center" style="vertical-align: middle;">NOMBRE MATERIA</th>
                    <th colspan="2" class="text-center">Primer parcial </th>
                    <th colspan="2" class="text-center">Segundo parcial </th>
                    <th colspan="2" class="text-center">Tercer parcial </th>
                    <th colspan="2" class="text-center">Calificación final </th>
                </tr>
                <tr>
                    <th colspan="1" class="text-center">Calif</th>
                    <th colspan="1" class="text-center">Faltas</th>
                    <th colspan="1" class="text-center">Calif</th>
                    <th colspan="1" class="text-center">Faltas</th>
                    <th colspan="1" class="text-center">Calif</th>
                    <th colspan="1" class="text-center">Faltas</th>
                    <th colspan="1" class="text-center">Número</th>
                    <th colspan="1" class="text-center">Letras</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $calificacionesParciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->nombreMateria); ?></td>

                        <td>
                            <label for=""><?php echo e($data->nota1); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->falta1); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->nota2); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->falta2); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->nota3); ?></label>
                        </td>
                        <td><label for=""><?php echo e($data->falta3); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->notaFinal); ?></label>
                        </td>
                        <td>
                            <label for=""><?php echo e($data->letra); ?></label>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/cursosInscrito.blade.php ENDPATH**/ ?>