

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                <img class="img-fluid" src="<?php echo asset('images/Logo_itec.png'); ?>" alt="">    
                </div>

                <div class="card-body">
                    <!--<form method="POST" action="<?php echo e(route('login')); ?>">-->
                        <?php echo csrf_field(); ?>
                        <div class="form-group row ">
                            <div class="col-md-12 offset-md-4">              
                                <a href="<?php echo e(route('login.google')); ?>" class="btn" style="background-color: #d5553f" style="color:white">
                                    <i class="fab fa-google mr-3 "></i>
                                    Inicia sesión con Google
                                </a> 
                                
                            </div>
                        </div> 
                <!--</form>-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/login.blade.php ENDPATH**/ ?>