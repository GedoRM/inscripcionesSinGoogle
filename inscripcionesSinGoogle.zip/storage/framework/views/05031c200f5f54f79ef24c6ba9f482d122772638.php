

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/estudiantes/acciones/calificaciones.blade.php ENDPATH**/ ?>