
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-eye mr-3"></i>Ver datos</h1>
<title></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
<li class="nav-item">
<a id="datos" href="<?php echo e(route('academy.infoStudent', $date->idAlumno)); ?>" class="nav-link active bg-blue">Datos</a>
</li>
<li class="nav-item">
<a style="color:black" href="<?php echo e(route('academy.viewDocuments', $date->idAlumno)); ?>" class="nav-link">Documentos</a>
</li>
</nav>
<div class="text-center p-5">

  <h3>DATOS PERSONALES</h3>
  <div class="form-row"><!--Columna Datos de Alumnos-->
    <div class="col-md-2 col-12">
      <div class="md-form">
        <label>Nombre del alumno:</label><br>
      </div>
    </div>
    <div class="col-12 col-md-2">
      <div class="md-form">
        <input type="text" id="ap" class="form-control" name="apePaterno" value="<?php echo e($date->apePaterno); ?>" disabled>
        <label for="">Apellido paterno</label>  
      </div>
    </div>
    <div class="col-12 col-md-2">
      <div class="md-form">
        <input type="text" id="am" class="form-control" name="apeMaterno" value="<?php echo e($date->apeMaterno); ?>" disabled>
        <label for="">Apellido materno</label>
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="nomb" class="form-control" name="nombre" value="<?php echo e($date->nombre); ?>" disabled>
        <label for="">Nombre (s)  </label>
      </div>
    </div>
  </div><!--Fin columna alumnos-->
  <br>
  <div class="form-row"><!--Columna edad-->
      <div class="col-md-2 col-12"></div>
      <div class="col-md-2 col-12">
        <div class="md-form">
          <input disabled type="text" id="edad" class="form-control" name="edad" onkeypress="return soloNumeros(event)" maxlength="2" value="<?php echo e($date->edad); ?>" >
          <label for="">Edad</label>
        </div>
      </div>
      <div class="col-md-2 col-12">
      <div class="md-form">
        <input disabled type="date" id="fecha" class="form-control" name="fecha" maxlength="10" value="<?php echo e($date->fechaNacimiento); ?>">
        <label for="">Fecha</label>
      </div>
    </div>
      <div class="col-md-4 col-12">
        <div class="md-form">
          <input disabled type="text" id="curp" class="form-control" name="curp" value="<?php echo e($date->curp); ?>" >
          <label for="">CURP</label>
        </div>
      </div>
    </div><!--fin Columna edad-->
    <br>
  <div class="form-row"><!--Columna Domicilio-->
    <div class="col-md-2 col-12">
      <div class="md-form">
        <label>Domicilio particular:</label>
      </div>
    </div>
    <div class="col-md-6 col-12">
      <div class="md-form">
        <input disabled type="text" id="calle" class="form-control" name="calle" value="<?php echo e($date->calle); ?>" >
        <label for="">Calle</label>
      </div>
    </div>
    <div class="col-md-2 col-12">
      <div class="md-form">
        <input disabled type="text" id="number" class="form-control" name="numero" value="<?php echo e($date->numCalle); ?>" >
        <label for="">Número</label>
      </div>
    </div>
  </div><!---Fin columna domicilio-->
  <br>
  <div class="form-row"><!--Columna colonia-->
    <div class="col-md-2 col-12"></div>
    <div class="col-md-5 col-12">
      <div class="md-form">
        <input disabled type="text" id="colonia" class="form-control" name="colonia" value="<?php echo e($date->colonia); ?>">
        <label for="">Colonia</label>
      </div>
    </div>
    <div class="col-md-3 col-12">
      <div class="md-form">
        <select class="browser-default custom-select" name="municipio" disabled>
          <option value="<?php echo e($date->idMunicipio); ?>" selected ="true"><?php echo e($date->nombreMunicipio); ?></option>
      </select><label for="">Municipio</label>
      </div>
    </div>
  </div><!--Fin columna colonia-->
  <br>
  <div class="form-row"><!--Columna telefono-->
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input disabled type="tel" id="telfij" class="form-control" name="telFijo" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telFijo); ?>" >
        <label for="">Teléfono local</label>
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">

        <input disabled type="tel" id="telcel" class="form-control" name="telCelular" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telCelular); ?>" >
        <label for="telcel">Teléfono Celular</label>
      </div>
    </div>
  </div><!--Fin telefono-->
  <br>
  <div class="form-row"><!--Columna correo-->
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="text" id="sexo" class="form-control" name="sexo" value="<?php echo e($date->sexo); ?>"  disabled>
      <label for="">Sexo</label>
    </div>
  </div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="email" id="email" class="form-control" name="correo" value="<?php echo e($date->correoAlumno); ?>">
      <label for="">Correo electrónico</label>
    </div>
  </div>
  <div class="col-md-2"></div>
  <div class="col-md-2"></div>
  <div class="col-md-4">
    <div class="md-form">
      
      <input disabled type="email" id="correoInstitucional" class="form-control" value="<?php echo e($date->correoInstitucional); ?>" disabled>
      <label for="">Correo institucional</label>
    </div>

  </div>
</div><!--Fin columna correo -->
<br>
<br>
<h3>DATOS ESCOLARES</h3>
<div class="form-row"><!--Columna dato escolar-->
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="text" id="esceg" class="form-control" name="escEgreso" value="<?php echo e($date->escEgreso); ?>" >
      <label for="">Escuela de egreso</label>
    </div>
  </div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="text" id="generacion" class="form-control" name="generacion" value="<?php echo e($date->generacion); ?>">
      <label for="">Generación</label>
    </div>
  </div>
  <div class="col-md-2 col-12"></div>
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="text" id="promEgreso" class="form-control" name="promEgreso" value="<?php echo e($date->promedioEgreso); ?>">
      <label for="">Promedio de egreso</label>
    </div>
  </div>
  
</div><!--Fin columna dato escolar-->
<br>
<h3>PROGRAMA DE BECAS</h3>

<div class="form-row">
  <div class="col-md-3"></div>
    <div class="col-md-6">
      <select class="browser-default custom-select text-center" name="tipoBeca" id="beca" disabled>
        <option value="<?php echo e($date->idTipoBeca); ?>"><?php echo e($date->nombreTipoBeca); ?></option>
      </select>
    </div>
    <div class="col-md-3"></div>
</div>
<br>
<div class="form-row" id="prom">
  <div class="col-md-3"></div>
    <div class="col-md-6">
      <div class="md-form">
        <select class="browser-default custom-select text-center" name="prom" id="prom" disabled>
        <option value="<?php echo e($date->idPromedio); ?>" ><?php echo e($date->promedio); ?></option>
        </select>
      </div>
    </div>
    <div class="col-md-3"></div>
</div>
<br>
<div class="form-row" id="porc">
  <div class="col-md-3"></div>
    <div class="col-md-6">
      <div class="md-form">
        <select class="browser-default custom-select text-center" name="porc" id="porc" disabled>
        <option  value="<?php echo e($date->idPorcentaje); ?>" ><?php echo e($date->porcentaje); ?></option>
        </select>
      </div> 
    </div>
    <div class="col-md-3"></div>
  </div>
  <br>
  <div class="form-row" id="conv">
      <div class="col-md-3"></div>
      <div class="col-md-6">
          <div class="md-form">
              <select class="browser-default custom-select text-center"  name="dependencia" disabled>
                  <option value="<?php echo e($date->idDependencia); ?>"><?php echo e($date->nombreDependencia); ?></option>
              </select>
          </div>      
      </div>
      <div class="col-md-3"></div>
  </div>
  <br>
  <div class="form-row" id="foraneo">
      <div class="col-md-3"></div>
      <div class="col-md-6">
          <div class="md-form">
              <select class="browser-default custom-select text-center" id="municipio" name="municipio" disabled>
                  <option value="<?php echo e($date->idMunicipio); ?>"><?php echo e($date->nombreMunicipio); ?></option>
              </select>					
          </div>
      </div>
      <div class="col-md-3"></div>
  </div>
  <br>
  <div class="form-row" id="locali">
      <div class="col-md-3"></div>
      <div class="col-md-6">
          <div class="md-form">
              <input disabled type="text" class="form-control" id="locali" name="localidad" placeholder="Localidad" value="<?php echo e($date->localidad); ?>">
          </div>
      </div>
      <div class="col-md-3"></div>
  </div>
  <br>
<h3>DATOS ACADÉMICOS</h3>
<div class="form-row"><!--Columna academicos-->
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <label>Selecciona un periodo</label>
      <select class="browser-default custom-select" name="perioInicio" disabled>
        <option value="<?php echo e($date->idPeriodo); ?>"><?php echo e($date->nombrePeriodo); ?> <?php echo e($date->anoPeriodo); ?></option>
      </select>
    </div>
  </div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <label>Selecciona una licenciatura</label>
      <select class="browser-default custom-select" id="selector" name="programa" disabled>
        <option value="<?php echo e($date->idPrograma); ?>"><?php echo e($date->nombrePrograma); ?></option>
      </select>
    </div>
  </div>
</div><!--Fin columna academicos-->
<br>
<div class="form-row">
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <label>Selecciona una modalidad</label>
      <select class="browser-default custom-select" name="modalidad" disabled>
        <option value="<?php echo e($date->idModalidad); ?>"><?php echo e($date->nombreModalidad); ?></option>
      </select>
    </div>
  </div>
</div><!--fin-->
<br>
<h3>DATOS DEL PADRE O TUTOR</h3>
<div class="form-row">
  <div class="col-md-2"></div>
  <div class="col-md-4">
    <div class="md-form">
      <input type="text" id="nombtutor" class="form-control" name="nombtutor" value="<?php echo e($date->nombreTutor); ?>" disabled>
      <label>Nombre</label>
    </div>
  </div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input type="text" id="parentesco" class="form-control" name="parentesco" value="<?php echo e($date->parentescoTutor); ?>" disabled>
      <label>Parentesco</label>
    </div>
  </div>
</div>
<br>
<div class="form-row">
  <div class="col-md-2 col-12"></div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input type="text" id="directutor" class="form-control" name="directutor" value="<?php echo e($date->domicilioTutor); ?>" disabled >
      <label>Dirección</label>
    </div>
  </div>
  <div class="col-md-4 col-12">
    <div class="md-form">
      <input disabled type="tel" id="teltutor" class="form-control" name="teltutor" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telTutor); ?>" >
      <label>Teléfono</label>
    </div>
  </div>
</div>
<br>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src=<?php echo e(asset('js/programaBecas.js')); ?>></script>

<script type="text/javascript">
function soloNumeros(e){
  var key = window.Event ? e.which : e.keyCode
  return (key >= 48 && key <= 57)
}
</script>

<script type="text/javascript">
$(function(){
 $("#myModal").modal();
});
</script>


<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/academy/students/viewInfo.blade.php ENDPATH**/ ?>