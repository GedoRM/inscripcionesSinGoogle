

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Pregunta</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->idPregunta); ?></td>
                    <td><?php echo e($item->nombrePregunta); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/evaluacionDocente/bancoPreguntas.blade.php ENDPATH**/ ?>