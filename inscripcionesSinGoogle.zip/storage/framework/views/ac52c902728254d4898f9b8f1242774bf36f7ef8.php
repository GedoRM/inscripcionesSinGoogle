<style>
    p{
        font-weight: 400;
    }
</style>



<?php $__env->startSection('header'); ?>
    <h1 class="m-0 text-dark"><i class="fas fa-file-alt mr-3"></i>Documentos del alumno</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
    <li class="nav-item">
    <a style="color:black" id="datos" href="<?php echo e(route('viewInfo', $date->idAlumno)); ?>" class="nav-link">Datos</a>
    </li>
    <li class="nav-item">
    <a  href="<?php echo e(route('documents', $date->idAlumno)); ?>" class="nav-link active bg-blue">Documentos</a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
    <li class="nav-item">
    <a style="color:black; " href="<?php echo e(route('reception', $date->idAlumno)); ?>" id="doc" class="nav-link">Recepción Documentos</a>
    </li>
    <?php endif; ?>
  </nav>
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <table class="table p-5">
            <thead>
                <tr>
                    <th scope="col">
                        <label><p>Nombre del documento</p></label>
                    </th>
                    <th scope="col">
                        <label><p>Documento</p></label>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <label for="acta_nacimiento"><p>Acta de nacimiento</p></label>
                    </td>
                   
                    <?php if($date->actaNacimiento != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->actaNacimiento); ?>'> <?php echo e($date->actaNacimiento); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="const_estudio"><p>Constancia de estudios o Certificado de bachillerato</p></label>
                        
                    </td>
                    
                    <?php if($date->constanciaEstudios != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->constanciaEstudios); ?>'> <?php echo e($date->constanciaEstudios); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="curp"><p>CURP</p></label>
                    </td>
                    
                    <?php if($date->curp != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->curp); ?>'> <?php echo e($date->curp); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td> 
                        <label for="ine"><p>INE o credencial escolar</p></label>
                    </td>
                    
                    <?php if($date->ine != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->ine); ?>'> <?php echo e($date->ine); ?></a>
                        </td>
                    <?php endif; ?> 
                </tr>
                <tr>
                    <td>
                        <label for="ine_tutor"><p>INE del tutor</p></label>
                    </td>
                    
                    <?php if($date->ineTutor != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->ineTutor); ?>'> <?php echo e($date->ineTutor); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="comp_domicilio"><p>Comprobante de domicilio</p></label>
                    </td>
                    
                    <?php if($date->comprobanteDomicilio != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->comprobanteDomicilio); ?>'> <?php echo e($date->comprobanteDomicilio); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>
                        <label for="foto"><p>Foto</p></label>
                    </td>
                    
                    <?php if($date->foto != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->foto); ?>'> <?php echo e($date->foto); ?></a>
                        </td>
                    <?php endif; ?>               
                </tr>
                <tr>
                    <td>
                        <label for="pago"><p>Comprobante de pago</p></label>
                    </td>
                    
                    <?php if($date->comprobantePago != null): ?>
                        <td>
                            <a href='/download/<?php echo e($date->comprobantePago); ?>'> <?php echo e($date->comprobantePago); ?></a>
                        </td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="col-md-2"></div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/students/actions/documents.blade.php ENDPATH**/ ?>