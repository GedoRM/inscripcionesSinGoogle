

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-user-edit mr-3"></i>Editar datos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<!--<script src="<?php echo e(asset('js/programaBecas.js')); ?>"></script>-->
<nav class ="nav nav-tabs justify-content-center grey" style="margin-top: -10px">
  <li class="nav-item">
  <a id="datos" href="#" class="nav-link active bg-blue">Datos</a>
  </li>
  <li class="nav-item">
  <a style="color:black" href="#" class="nav-link">Documentos</a>
  </li>
  <li class="nav-item">
  <a style="color:black; " href="#" id="doc" class="nav-link">Recepción Documentos</a>
  </li>
</nav>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form class="text-center p-5" action="#" method="POST">
    <h3>DATOS PERSONALES</h3>
    <div class="form-row"><!--Columna Datos de Alumnos-->
      <div class="col-md-2 col-12">
        <div class="md-form">
          <label>Nombre del alumno:</label><br>
        </div>
      </div>
      <div class="col-12 col-md-2">
        <div class="md-form">
          <input type="text" id="ap" class="form-control" name="apepat" value="<?php echo e($date->apePaterno); ?>">
          <label for="">Apellido paterno</label>  
        </div>
      </div>
      <div class="col-12 col-md-2">
        <div class="md-form">
          <input type="text" id="am" class="form-control" name="apemat" value="<?php echo e($date->apeMaterno); ?>" >
          <label for="">Apellido materno</label>
        </div>
      </div>
      <div class="col-md-4 col-12">
        <div class="md-form">
          <input type="text" id="nomb" class="form-control" name="nombre" value="<?php echo e($date->nombre); ?>">
          <label for="">Nombre (s)  </label>
        </div>
      </div>
    </div><!--Fin columna alumnos-->
    <br>
    <div class="form-row"><!--Columna edad-->
        <div class="col-md-2 col-12"></div>
        <div class="col-md-2 col-12">
          <div class="md-form">
            <input type="text" id="edad" class="form-control" name="edad" onkeypress="return soloNumeros(event)" maxlength="2" value="<?php echo e($date->edad); ?>" >
            <label for="">Edad</label>
          </div>
        </div>
        <div class="col-md-2 col-12">
        <div class="md-form">
          <input type="date" id="fecha" class="form-control" name="fecha" maxlength="10" value="<?php echo e($date->fechaNacimiento); ?>">
          <label for="">Fecha</label>
        </div>
      </div>
        <div class="col-md-4 col-12">
          <div class="md-form">
            <input type="text" id="curp" class="form-control" name="curp" value="<?php echo e($date->curp); ?>" >
            <label for="">CURP</label>
          </div>
        </div>
      </div><!--fin Columna edad-->
      <br>
    <div class="form-row"><!--Columna Domicilio-->
      <div class="col-md-2 col-12">
        <div class="md-form">
          <label>Domicilio particular:</label>
        </div>
      </div>
      <div class="col-md-6 col-12">
        <div class="md-form">
          <input type="text" id="calle" class="form-control" name="calle" value="<?php echo e($date->calle); ?>" >
          <label for="">Calle</label>
        </div>
      </div>
      <div class="col-md-2 col-12">
        <div class="md-form">
          <input type="text" id="number" class="form-control" name="numero" value="<?php echo e($date->numCalle); ?>" >
          <label for="">Número</label>
        </div>
      </div>
    </div><!---Fin columna domicilio-->
    <br>
    <div class="form-row"><!--Columna colonia-->
      <div class="col-md-2 col-12"></div>
      <div class="col-md-5 col-12">
        <div class="md-form">
          <input type="text" id="colonia" class="form-control" name="colonia" value="<?php echo e($date->colonia); ?>">
          <label for="">Colonia</label>
        </div>
      </div>
      <div class="col-md-3 col-12">
        <div class="md-form">
          <select class="browser-default custom-select" name="municipio">
            <option value="" selected ="true"><?php echo e($date->nombreMunicipio); ?></option>
            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($municipio->idMunicipio); ?>"><?php echo e($municipio->nombreMunicipio); ?></option>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><label for="">Municipio</label>
        </div>
      </div>
    </div><!--Fin columna colonia-->
    <br>
    <div class="form-row"><!--Columna telefono-->
      <div class="col-md-2 col-12"></div>
      <div class="col-md-4 col-12">
        <div class="md-form">
          <input type="tel" id="telfij" class="form-control" name="telfijo" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telFijo); ?>" >
          <label for="">Teléfono local</label>
        </div>
      </div>
      <div class="col-md-4 col-12">
        <div class="md-form">

          <input type="tel" id="telcel" class="form-control" name="telcelular" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telCelular); ?>" >
          <label for="telcel">Teléfono Celular</label>
        </div>
      </div>
    </div><!--Fin telefono-->
    <br>
    <div class="form-row"><!--Columna correo-->
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="sexo" class="form-control" name="correo" value="<?php echo e($date->sexo); ?>"  disabled>
        <label for="">Sexo</label>
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="email" id="email" class="form-control" name="correo" value="<?php echo e($date->correoAlumno); ?>">
        <label for="">Correo electrónico</label>
      </div>
    </div>
  </div><!--Fin columna correo -->
  <br>
  <br>
  <h3>DATOS ESCOLARES</h3>
  <div class="form-row"><!--Columna dato escolar-->
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="esceg" class="form-control" name="esceg" value="<?php echo e($date->escEgreso); ?>" >
        <label for="">Escuela de egreso</label>
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="generacion" class="form-control" name="generacion" value="<?php echo e($date->generacion); ?>">
        <label for="">Generación</label>
      </div>
    </div>
    <div class="col-md-2 col-12"></div>
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="promEgreso" class="form-control" name="promEgreso" value="<?php echo e($date->promedioEgreso); ?>">
        <label for="">Promedio de egreso</label>
      </div>
    </div>
    
  </div><!--Fin columna dato escolar-->
  <br>
  <h3>PROGRAMA DE BECAS</h3>
  
  <div class="form-row">
    <div class="col-md-3"></div>
      <div class="col-md-6">
        <select class="browser-default custom-select text-center" name="beca" id="beca">
          <option value="1"><?php echo e($date->nombreTipoBeca); ?></option>
          <?php $__currentLoopData = $type_beca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tBeca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tBeca->idTipoBeca); ?>"><?php echo e($tBeca->nombreTipoBeca); ?></option>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-3"></div>
  </div>
  <br>
  <div class="form-row" id="prom">
    <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="md-form">
          <select class="browser-default custom-select text-center" name="prom" id="prom">
          <option value="<?php echo e($date->idPromedio); ?>" disabled><?php echo e($date->promedio); ?></option>
          <?php $__currentLoopData = $promedios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promedio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($promedio->idPromedio); ?>"><?php echo e($promedio->promedio); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
      <div class="col-md-3"></div>
  </div>
  <br>
  <div class="form-row" id="porc">
    <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="md-form">
          <select class="browser-default custom-select text-center" name="porc" id="porc">
          <option  value="<?php echo e($date->idPorcentaje); ?>" disabled><?php echo e($date->porcentaje); ?></option>
          <?php $__currentLoopData = $porcentajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $porcentaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($porcentaje->idPorcentaje); ?>"><?php echo e($porcentaje->porcentaje); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div> 
      </div>
      <div class="col-md-3"></div>
    </div>
    <br>
    <div class="form-row" id="conv">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="md-form">
                <select class="browser-default custom-select"  name="dependencia" required="">
                    <option value="<?php echo e($date->idDependencia); ?>" disabled><?php echo e($date->nombreDependencia); ?></option>
                    <?php $__currentLoopData = $dependencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($dependencia->idDependencia); ?>"><?php echo e($dependencia->nombreDependencia); ?></option>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>      
        </div>
        <div class="col-md-3"></div>
    </div>
    <br>
    <div class="form-row" id="foraneo">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="md-form">
                <select class="browser-default custom-select" id="municipio" name="municipio" disabled>
                    <option value="<?php echo e($date->idMunicipio); ?>"><?php echo e($date->nombreMunicipio); ?></option>
                </select>					
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
    <br>
    <div class="form-row" id="locali">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="md-form">
                <input type="text" class="form-control" id="locali" name="locali" placeholder="Localidad" value="<?php echo e($date->localidad); ?>">
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
    <br>
  <h3>DATOS ACADÉMICOS</h3>
  <div class="form-row"><!--Columna academicos-->
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <select class="browser-default custom-select" name="perioini">
          <option value="<?php echo e($date->idPeriodo); ?>"><?php echo e($date->nombrePeriodo); ?> <?php echo e($date->anoPeriodo); ?></option>
          <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($periodo->idPeriodo); ?>"><?php echo e($periodo->nombrePeriodo); ?> <?php echo e($date->anoPeriodo); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <select class="browser-default custom-select" id="selector" name="programa">
          <option value="<?php echo e($date->idPrograma); ?>"><?php echo e($date->nombrePrograma); ?></option>
          <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($programa->idPrograma); ?>"><?php echo e($programa->nombrePrograma); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
  </div><!--Fin columna academicos-->
  <br>
  <div class="form-row">
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <select class="browser-default custom-select" name="modalidad">
          <option value="<?php echo e($date->idModalidad); ?>"><?php echo e($date->nombreModalidad); ?></option>
          <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($modalidad->idModalidad); ?>"><?php echo e($modalidad->nombreModalidad); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
  </div><!--fin-->
  <br>
  <h3>DATOS DEL PADRE O TUTOR</h3>
  <div class="form-row">
    <div class="col-md-2"></div>
    <div class="col-md-4">
      <div class="md-form">
        <input type="text" id="nombtutor" class="form-control" name="nombtutor" value="<?php echo e($date->nombreTutor); ?>" >
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="parentesco" class="form-control" name="parentesco" value="<?php echo e($date->parentescoTutor); ?>">
      </div>
    </div>
  </div>
  <br>
  <div class="form-row">
    <div class="col-md-2 col-12"></div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="text" id="directutor" class="form-control" name="directutor" value="<?php echo e($date->domicilioTutor); ?>" >
      </div>
    </div>
    <div class="col-md-4 col-12">
      <div class="md-form">
        <input type="tel" id="teltutor" class="form-control" name="teltutor" onkeypress="return soloNumeros(event)" value="<?php echo e($date->telTutor); ?>" >
      </div>
    </div>
  </div>
  <br>
  <div class="col-12">
    <div class="custom-control custom-checkbox">
      <input type="checkbox" class="custom-control-input" id="check" value="0" name="check">
        <label class="custom-control-label" for="check">Habilitar carta compromiso</label><br>
    </div>
  </div>
  <br>
    <div class="col-md-12">
    <a href="<?php echo e(route('list_students')); ?>"><button type="button" class="btn btn-danger btn-sm" >Volver</button></a>
        <input type="submit" class="btn btn-success btn-sm" name="enviar" value="Actualizar">
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script src=<?php echo e(asset('js/programaBecas.js')); ?>></script>

<script type="text/javascript">
  function soloNumeros(e){
    var key = window.Event ? e.which : e.keyCode
    return (key >= 48 && key <= 57)
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/students/actions/edit.blade.php ENDPATH**/ ?>