
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

<?php if(session('yaInscrito')): ?>
<div class="col-md-6">
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    <?php echo e(session('yaInscrito')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
<?php if(session('mensaje')): ?>
<div class="col-md-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('mensaje')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
<?php if(session('mensaje_error')): ?>
<div class="col-md-6">
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('mensaje_error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
<?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    
  <form id="formulario" action="<?php echo e(route('enrolleToCourse', ['idCurso' => $curso->idCurso])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-5" style="display:block; margin:auto">
            <h3>Alumnos no inscritos</h3>
                <select multiple id="" size="20" style="width:350px" name="alumnos[]">   
                  <?php if(count($alumnos) == 0): ?> 
                <option value="1" class="text-center">No hay usuarios</option>
                <?php else: ?>
                    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($alumno->idAlumno); ?>"><?php echo e($alumno->nombre); ?> <?php echo e($alumno->apePaterno); ?> <?php echo e($alumno->apeMaterno); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            
        </div>
        <div class="col-md-2" style="display: block; margin:auto">
            <input name="add" class="btn btn-success" type="submit" value=">>">
                <br><br>
            <input name="del" type="submit" class="btn btn-success" value="<<">
        </div>
        <div class="col-md-5" style="display:block; margin:auto">
            <h3>Alumnos inscritos</h3>
            <select id="" multiple size="20" style="width:350px" name="delAlu[]">
                <?php if(count($inscritos) == 0): ?> 
                <option value="1" class="text-center">No se han inscrito usuarios</option>
                <?php else: ?>
                <?php $__currentLoopData = $inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($alumno->idUserCourse); ?>"> <?php echo e($alumno->nombre); ?> <?php echo e($alumno->apePaterno); ?> <?php echo e($alumno->apeMaterno); ?></option>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
      
    </div>
  </form>
  
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/course/actions/enrolleStudent.blade.php ENDPATH**/ ?>