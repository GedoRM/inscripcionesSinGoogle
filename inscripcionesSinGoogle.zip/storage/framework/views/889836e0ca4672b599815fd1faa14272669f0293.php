

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.7/css/responsive.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(session('mensaje')): ?>
<div class="col-md-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('mensaje')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
  
<button class="btn btn-success btn-sm" data-target="#modalNewMaterie" data-toggle="modal">
    <i class="fas fa-plus mr-3"></i>Añadir nueva materia
</button>
<br><br>
<table id="oScroll" class="display table table-bordered nowrap" style="width: 100%; word-break: break-all" >
    <thead class="text-center">
        <tr>
            <th>CLAVE</th>
            <th>NOMBRE</th>
            <th>CRÉDITOS</th>
            <th>LICENCIATURA</th>
            <th>MODALIDAD</th>
            <th>CUATRIMESTRE</th>
            <th>ACCIONES</th>
            
            
        </tr>
    </thead>
    <tbody class="text-center">
        <?php $__currentLoopData = $list_materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($materias->claveMateria); ?></td>
                <td class="text-left"><?php echo e($materias->nombreMateria); ?></td>
                <td><?php echo e($materias->creditos); ?></td>
                <td><?php echo e($materias->nombrePrograma); ?></td>
                <td><?php echo e($materias->nombreModalidad); ?></td>
                <td><?php echo e($materias->numeroCuatrimestre); ?></td>
                <td>
                <button class="btn btn-warning btn-sm"><i class="fas fa-pen" style="color:white" data-toggle="modal" data-target="#modalEditMaterie<?php echo e($materias->idMateria); ?>">
                    </i>
                </button>
            <div class="modal fade" id="modalEditMaterie<?php echo e($materias->idMateria); ?>" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <form action=<?php echo e(route('update.materie', $materias->idMateria)); ?> method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                        <div class="modal-content">
                            <div class="modal-header text-center" >
                            <h4 class="modal-title w-100 font-weight-bold" style="word-break:break-all">Editar</h4>
                                
                            </div>
                            <div class="modal-body mx-3 text-left">
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Nombre de la materia</label>
                                    <input type="text" class="form-control validate" name="nombreMateria"
                                     value="<?php echo e($materias->nombreMateria); ?>">
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Clave de la materia</label>
                                    <input type="text" class="form-control validate" name="claveMateria" value="<?php echo e($materias->claveMateria); ?>">
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Créditos de la materia</label>
                                    <input type="text" class="form-control validate" name="creditosMateria" value="<?php echo e($materias->creditos); ?>">
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Licenciatura</label><br>
                                    <select name="programa" class="browser-default custom-select"> 
                                    <option value="<?php echo e($materias->idPrograma); ?>"> <?php echo e($materias->nombrePrograma); ?></option>
                                        <?php $__currentLoopData = $list_lic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->idPrograma); ?>"><?php echo e($item->nombrePrograma); ?></option>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Sistema</label><br>
                                    <select name="modalidad" class="browser-default custom-select">
                                    <option value="<?php echo e($materias->idModalidad); ?>"><?php echo e($materias->nombreModalidad); ?></option>
                                        <?php $__currentLoopData = $list_sistema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->idModalidad); ?>"><?php echo e($item->nombreModalidad); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="md-form mb-5">
                                    <label data-error="wrong" data-success="right">Cuatrimestre</label><br>
                                    <select name="cuatrimestre" class="browser-default custom-select">
                                    <option value="<?php echo e($materias->idCuatrimestre); ?>"><?php echo e($materias->numeroCuatrimestre); ?></option>
                                        <?php $__currentLoopData = $list_cuatri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->idCuatrimestre); ?>"><?php echo e($item->numeroCuatrimestre); ?></option>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer d-flex justify-content-center">
                                <button type="submit" class="btn btn-success btn-sm">Actualizar</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
                         
                <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                
                </td>
            </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
 



<div class="modal fade" id="modalNewMaterie" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action=<?php echo e(route('addMateries')); ?> method="post">
            <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Añadir nueva materia</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body mx-3">
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right" for="defaultForm-email">Nombre de la materia</label>
                <input type="text" id="defaultForm-email" class="form-control validate" name="nombreMateria">
                </div>
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right" for="defaultForm-email">Clave de la materia</label>
                    <input type="text" id="defaultForm-email" class="form-control validate" name="claveMateria">
                </div>
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right">Créditos de la materia</label>
                    <input type="text" class="form-control validate" name="creditosMateria" >
                </div>
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right" for="defaultForm-email">Licenciatura</label><br>
                    <select name="licenciatura" id="" class="browser-default custom-select">
                        <?php $__currentLoopData = $list_lic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->idPrograma); ?>"><?php echo e($item->nombrePrograma); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right" for="defaultForm-email">Sistema</label>
                    <select name="modalidad" id="" class="browser-default custom-select">
                        <?php $__currentLoopData = $list_sistema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->idModalidad); ?>"><?php echo e($item->nombreModalidad); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="md-form mb-5">
                    <label data-error="wrong" data-success="right" for="defaultForm-email">Cuatrimestre</label>
                    <select name="cuatrimestre" id="" class="browser-default custom-select">
                        <?php $__currentLoopData = $list_cuatri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->idCuatrimestre); ?>"><?php echo e($item->numeroCuatrimestre); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button type="submit" class="btn btn-success btn-sm">Añadir</button>
            </div>
        </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.7/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.7/js/responsive.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/materies/list_materies.blade.php ENDPATH**/ ?>