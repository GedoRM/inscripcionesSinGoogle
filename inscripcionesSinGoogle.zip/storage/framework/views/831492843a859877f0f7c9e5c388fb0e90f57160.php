

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="far fa-list-alt mr-3"></i>Cursos Asignados</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <table id="wScroll" class="display table nowrap table-bordered" style="width: 100%">
        <thead class="text-center">
            <tr>
                <th>CLAVE DE LA MATERIA</th>
                <th>NOMBRE DE LA MATERIA</th>
                <th>CUATRIMESTRE</th>
                <th>PROGRAMA</th>
                <th>MODALIDAD</th>
                <th>STATUS</th>
                <th>FECHA INICIO</th>
                <th>FECHA FINAL</th>
                <th>ACCIONES</th>
            </tr>
        </thead>
        <tbody>
<?php $__currentLoopData = $maestroCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($item->claveMateria); ?></td>
        <td><?php echo e($item->nombreMateria); ?></td>
        <td class="text-center"><?php echo e($item->numeroCuatrimestre); ?></td>
        <td class="text-center"><?php echo e($item->nombrePrograma); ?></td>
        <td class="text-center"><?php echo e($item->nombreModalidad); ?></td>
        <td class="text-center"><?php echo e($item->status); ?></td>
        <td class="text-center"><?php echo e($item->fecha_inicio); ?></td>
        <td class="text-center"><?php echo e($item->fecha_final); ?></td>
        <td class="text-center"><a href="<?php echo e(route('inscritosCurso', ['idDocente' => $id, 'idCurso' => $item->idCurso])); ?>"><button class="btn btn-primary" title="Inscritos curso"><i class="fas fa-clipboard-list"></i></button></a></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>


    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/teacher/cursosAsignados.blade.php ENDPATH**/ ?>