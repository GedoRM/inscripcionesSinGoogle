<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title>Document</title>    
</head>
<body>
    <img src="images/Logo_itec.png" alt="" style="display: block; width:50%; height:auto">

    <h2 style="font-weight: 600; text-align:center">Servicios Escolares</h2>
    <h2 style="font-weight:400; text-align:center">Recepción de Documentos</h2>
    
    <p style="text-align: right"><?php echo e($data[0]); ?></p>
    <p style="text-align: left">Nombre del alumno: <?php echo e($data[1]); ?></p>
    <p style="text-align: left">Licenciatura: <?php echo e($data[2]); ?></p>
    <p style="text-align: left">Modalidad: <?php echo e($data[3]); ?></p>
    <p style="text-align: left">Cuatrimestre: <?php echo e($data[4]); ?></p>
    <br><br><br>
        <table class="table">
            <thead>
                <tr>
                <th colspan="4" style="text-align: center;">Documentos</th>
                <th colspan="2">Observaciones</th>
                </tr>
                <tr>
                    <th><br></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($item->actaOriginal == 1): ?>
                        <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                        <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>    
                    <td>Acta de nacimiento (Original)</td>

                    <td colspan="2" style="word-wrap: break-word"><?php echo e($item->observaciones); ?></td>
                </tr>
                <tr>
                    <?php if($item->curpOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>CURP</td>
                </tr>
                <tr>
                    <?php if($item->certificadoOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>Certificado de Bachillerato</td>
                </tr>
                <tr>
                    <?php if($item->constanciaOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>Constancia de Estudios</td>
                </tr>
                <tr>
                    <?php if($item->fotoOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>Fotográfias (4)</td>
                </tr>
                <tr>
                    <?php if($item->ineAlumnoOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>INE del alumno (Copia)</td>
                </tr>
                <tr>
                    <?php if($item->ineTutorOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>INE del padre o tutor (Copia)</td>
                </tr>
                <tr>
                    <?php if($item->comprobanteDomicilioOriginal == 1): ?>
                            <td><input type="checkbox" name="" id="" checked style="padding-right: 20px"></td>
                    <?php else: ?>
                            <td><input type="checkbox" name="" id="" style="padding-right: 20px"></td>
                    <?php endif; ?>
                    <td>Comprobante de Domicilio</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            </tbody>
        </table>
            <img src="images/pie_pdf.png" style="margin-left:21px; width:100%; margin-top:210px; height:auto">


</body>
</html><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/pdf/recepcionDocumentos/recepcionDocumentos.blade.php ENDPATH**/ ?>