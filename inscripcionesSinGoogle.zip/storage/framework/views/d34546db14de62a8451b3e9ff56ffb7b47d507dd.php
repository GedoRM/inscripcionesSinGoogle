<li class="nav-item ml-1">
    <a href=<?php echo e(route('miPerfil', Auth::user()->id)); ?> class="nav-link">
      <i class="fas fa-user mr-3"></i>
      <p>
        Perfil
      </p>
    </a>
  </li>
  <li class="nav-item ml-1">
    <a href=<?php echo e(route('boleta', Auth::user()->id)); ?> class="nav-link">
      <i class="fas fa-clipboard-list mr-3"></i>
      <p>
        Boleta de Calificaciones  
      </p>
    </a>
  </li>
  <li class="nav-item ml-1">
    <a href=<?php echo e(route('historialPago', Auth::user()->id)); ?> class="nav-link">
      <i class="fas fa-landmark mr-3"></i>
      <p>
        Historial de pagos 
      </p>
    </a>
  </li><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/menu/alumno.blade.php ENDPATH**/ ?>