

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="m-0 text-dark"><i class="fas fa-user mr-3"></i>
            <?php echo e($item->nombre . ' ' . $item->apePaterno . ' ' . $item->apeMaterno); ?></h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-md-4">
            <?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5>Modalidad: <?php echo e($item->nombreModalidad); ?></h5>
                <h5>Programa: <?php echo e($item->nombrePrograma); ?></h5>
                <h5>Cuatrimestre: <?php echo e($item->numeroCuatrimestre); ?></h5>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <div class="container">

        <div class="col-md-4 d-block m-auto">
            <form id="cuatri">
                <?php echo csrf_field(); ?>
                <select name="cuatrimestre" class="browser-default custom-select" id="cuatrimestre">
                    <option value=" " selected disabled>Seleciona un cuatrimestre</option>
                    <?php $__currentLoopData = $cuatrimestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->idCuatrimestre); ?>"><?php echo e($item->numeroCuatrimestre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </div>
    </div>
    <br><br>
    <div id="resp">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
    <script>
        $(document).on('ready', function() {
            $("#cuatrimestre").on('change', function() {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('buscarCursoPorCuatri', $id)); ?>",
                    data: $("#cuatri").serialize(),
                    success: function(data) {
                        $("#resp").html(data);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/estudiantes/acciones/verCursosInscrito.blade.php ENDPATH**/ ?>