

<?php $__env->startSection('css'); ?>
    <style>
        th {
            width: 250px;
            word-break: break-all;
            text-align: center;
        }

    </style>
<?php $__env->stopSection(); ?>

<!--------------PENDIENTE--------------->
<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
    $cont = 1;
    $creditosAcreditados = 0;
    $creditosTotales = 0;
    ?>

    <?php $__currentLoopData = $cuatrimestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $creditosTotales = $creditosTotales + $item->creditos; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="container">
        <div class="content-justify-center">
            <table class="table table-bordered">
                <thead class="text-center">
                    <tr>
                        <th>No</th>
                        <th>CLAVE</th>
                        <th>NOMBRE DE LA MATERIA</th>
                        <th>CALIFICACIÓN</th>
                        <th>CR</th>
                    </tr>
                </thead>
                <tbody>
                    <td colspan="5" class="text-center">Primer cuatrimestre</td>
                    <?php $__currentLoopData = $avanceReticular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <?php if($item->notaFinal >= 6): ?>
                                <?php
                                $creditosAcreditados = $creditosAcreditados + $item->creditos;
                                ?>
                            <?php else: ?>
                                <?php
                                $creditosAcreditados = $creditosAcreditados + 0;
                                ?>
                            <?php endif; ?>
                            <td style="width: 5%" class="text-center"><?php echo e($cont); ?></td>
                            <td style="width: 10%"><?php echo e($item->claveMateria); ?></td>
                            <td><?php echo e($item->nombreMateria); ?></td>
                            <td style="width: 20%" class="text-center"><?php echo e($item->notaFinal); ?></td>
                            <td style="width: 10%" class="text-center"><?php echo e($item->creditos); ?></td>
                        </tr>
                        <?php if($cont == 5): ?>
                            <td colspan="5" class="text-center">Segundo cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 10): ?>
                            <td colspan="5" class="text-center">Tercer cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 15): ?>
                            <td colspan="5" class="text-center">Cuarto cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 20): ?>
                            <td colspan="5" class="text-center">Quinto cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 25): ?>
                            <td colspan="5" class="text-center">Sexto cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 30): ?>
                            <td colspan="5" class="text-center">Septimo cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 35): ?>
                            <td colspan="5" class="text-center">Octavo cuatrimestre</td>
                        <?php endif; ?>
                        <?php if($cont == 40): ?>
                            <td colspan="5" class="text-center">Noveno cuatrimestre</td>
                        <?php endif; ?>
                        <?php $cont++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php ?>

            <table class="table table-bordered d-block m-auto" style="width: 50%">
                <thead class="text-center">
                    <tr>
                        <th colspan="3">CRÉDITOS</th>
                    </tr>
                    <tr>
                        <th>ACREDITADOS</th>
                        <th>FALTANTES</th>
                        <th>TOTALES</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <tr>
                        <td style="width: 33%"><?php echo e($creditosAcreditados); ?></td>
                        <td style="width: 33%"><?php echo e($creditosFaltantes = $creditosTotales - $creditosAcreditados); ?></td>
                        <td style="width: 33%"><?php echo e($creditosTotales); ?></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/students/ver/avanceReticular.blade.php ENDPATH**/ ?>