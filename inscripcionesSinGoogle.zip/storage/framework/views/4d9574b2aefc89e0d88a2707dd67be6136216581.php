

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-users mr-3"></i>Lista de alumnos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<table id="oScroll" class="display table table-bordered nowrap" style="width: 100%"  >
    <thead class="text-center">
        <tr>
            <th>ACCIONES</th>
            <th>ID</th>
            <th>ESTATUS</th>
            <th>NOMBRE (S)</th>
            <th>APELLIDO (S)</th>
            <th>PROGRAMA</th>
            <th>CORREO INSTITUCIONAL</th>
            <th>FECHA</th>
        </tr>
    </thead>
    <tbody class="">
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center">
                <a href="<?php echo e(route('academy.infoStudent', $students->idAlumno)); ?>"><button class="btn btn-warning btn-sm" title="Ver"><i class="fas fa-eye" style="color:white"></i></i></button></a>
                <a href="<?php echo e(route('pagos', $students->idAlumno)); ?>"><button class="btn btn-success btn-sm" title="Pagos"><i class="fas fa-hand-holding-usd" style="color: white"></i></button></a>
                <a href="<?php echo e(route('viewCalificaciones', $students->idAlumno)); ?>"> <button class="btn btn-info btn-sm" title="Calificaciones"><i class="fas fa-clipboard-list"></i></button></a>
            </td> 
            <td><?php echo e($id= $students->idAlumno); ?></td>    
            <td id="estatus"><?php echo e($students->nombreEstatus); ?></td>
            <td><?php echo e($students->nombre); ?></td>
            <td><?php echo e($students->apePaterno); ?> <?php echo e($students->apeMaterno); ?> </td>
            <td><?php echo e($students->nombrePrograma); ?></td>
            <td><?php echo e($students->correoInstitucional); ?></td>
            <td><?php echo e($students->fechaRegistro); ?></td>
            
           </tr>           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/academy/students/viewStudents.blade.php ENDPATH**/ ?>