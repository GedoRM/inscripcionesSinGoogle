

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="m-0 text-dark"><i class="fas fa-users mr-3"></i>Lista de alumnos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(session('cambio')): ?>
<div class="col-md-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('cambio')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>
<?php if(session('noCambio')): ?>
<div class="col-md-6">
  <div class="alert alert-light alert-dismissible fade show" role="alert">
    <?php echo e(session('noCambio')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?>

<table id="wScroll" class="display table table-bordered nowrap" style="width: 100%"  >
    <thead class="text-center">
        <tr>
            <th>ACCIONES</th>
            <th>ID</th>
            <th>ESTATUS</th>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
            <th>ASESOR</th>
            <?php endif; ?>
            <th>NOMBRE (S)</th>
            <th>APELLIDO (S)</th>
            <th>PROGRAMA</th>
            <th>CORREO INSTITUCIONAL</th>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
            <th>TÉRMINOS Y <br>CONDICIONES</th>
            <th>CARTA <br> COMPROMISO</th>
            <?php endif; ?>
            <th>FECHA</th>
            
        </tr>
    </thead>
    <tbody class="">
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center">
                <a href="<?php echo e(route('viewInfo', $students->idAlumno)); ?>"><button class="btn btn-warning btn-sm" title="Editar"><i class="fas fa-pen" style="color:white"></i></button></a>
                <a href="<?php echo e(route('pagos', $students->idAlumno)); ?>"><button class="btn btn-success btn-sm" title="Pagos"><i class="fas fa-hand-holding-usd" style="color: white"></i></button></a>
                <a href="<?php echo e(route('viewCalificaciones', $students->idAlumno)); ?>"> <button class="btn btn-info btn-sm" title="Calificaciones"><i class="fas fa-clipboard-list"></i></button></a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
                <button class="btn btn-danger btn-sm" title="Eliminar"><i class="fas fa-trash"></i></button>
                <?php endif; ?>
            </td>
            <td>
                <a class="btn" data-target="#changeStatus" data-toggle="modal">
                    <?php echo e($id= $students->idAlumno); ?>

                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
                <div class="modal fade" id="changeStatus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <form action="<?php echo e(route('updateStatus', $id)); ?>" method="post">
                            <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header text-center">
                                <h4 class="modal-title w-100 font-weight-bold">Cambiar datos</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body mx-3">
                                <div class="md-form mb-5">
                                    <label for="">ID del alumno</label>
                                    <input type="text" value="<?php echo e($students->idAlumno); ?>" name="idAlumno" class="form-control validate">
                                </div>
                                <div class="md-form mb-5">
                                    <label for="">Estatus del alumno</label><br>
                                    <select class="browser-default custom-select" name="estatus" id="">
                                        <option value="<?php echo e($students->idEstatusAlumno); ?>" disabled selected>Selecciona un estatus</option>
                                        <option value="<?php echo e($students->idEstatusAlumno); ?>" selected hidden><?php echo e($students->nombreEstatus); ?></option>
                                        <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($estatus->idEstatusAlumno); ?>"><?php echo e($estatus->nombreEstatus); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="md-form mb-5">
                                    <label for="">Asesor del alumno</label><br>
                                    <select class="browser-default custom-select" name="" id="">
                                        <option value="" disabled>Selecciona un asesor</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer d-flex justify-content-center">
                                <button type="submit" class="btn btn-success btn-sm">Guardar cambios</button>
                            </div>
                        </div>
                        
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            
            </td>
            
            <td id="estatus"><?php echo e($students->nombreEstatus); ?></td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
            <td style="text-align:center; border-left:1px solid #dee2e6"><?php echo e($students->idAsesores); ?></td>
            <?php endif; ?>
            <td><?php echo e($students->nombre); ?></td>
            <td><?php echo e($students->apePaterno); ?> <?php echo e($students->apeMaterno); ?> </td>
            <td><?php echo e($students->nombrePrograma); ?></td>
            <td><?php echo e($students->correoInstitucional); ?></td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
                
            <td class="text-center"><?php echo e($students->termyCond); ?></td>
            <td class="text-center"><?php echo e($students->cartaCompromiso); ?></td>
            <?php endif; ?>
            <td><?php echo e($students->fechaRegistro); ?></td>
            
           </tr>           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/admin/students/viewListStudents.blade.php ENDPATH**/ ?>