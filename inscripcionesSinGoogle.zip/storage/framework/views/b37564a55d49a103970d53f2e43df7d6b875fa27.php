   
<div class="container">
    <h4 class="text-center">Mis cursos</h4>
    
  <div class="row">
    <?php $__currentLoopData = $teacherCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6">
      <a href="<?php echo e(route('detail', $data->idCurso)); ?>">
      <div class="card">
        <div class="card-body text-center nowrap">
          <div class="row">
            <p><strong>Materia: </strong> </p> <p> <?php echo e($data->nombreMateria); ?></p>
          </div>
          <hr>
        </div>
      </div>
    </a>
      
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
   
  </div>
<?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/profiles/teacher/main.blade.php ENDPATH**/ ?>