

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <h3><i class="fas fa-users mr-3"></i>Alumnos inscritos</h3>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensajeCorrecto')): ?>
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('mensajeCorrecto')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

        </div>
    <?php endif; ?>
    <?php if(session('mensajeError')): ?>
        <div class="col-md-6">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('mensajeError')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-4">
            <?php $__currentLoopData = $detallesMateria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5>Programa: <?php echo e($item->nombreMateria); ?></h5>
                <h5>Modalidad: <?php echo e($item->nombreModalidad); ?></h5>
                <h5>Cuatrimestre: <?php echo e($item->numeroCuatrimestre); ?></h5>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br>
    <div class="container-fluid">
        <div class="col-md-12 col-sm-8">
            <table id="Scroll" class="table table-sm table-bordered nowrap">

                <thead class="text-center">
                    <tr>
                        <th rowspan="2" style="vertical-align: middle"> MATRÍCULA</th>
                        <th rowspan="2" style="vertical-align: middle">NOMBRE ALUMNO</th>
                        <th colspan="2" class="text-center">PRIMER PARCIAL </th>
                        <th colspan="2" class="text-center">SEGUNDO PARCIAL </th>
                        <th colspan="2" class="text-center">TERCER PARCIAL </th>
                        <th colspan="2" class="text-center">CALIFICACIÓN FINAL </th>
                        <th rowspan="2" class="text-center" style="vertical-align: middle">ACCIONES</th>
                    </tr>
                    <tr>
                        <th colspan="1" class="text-center">CALIFICACIÓN</th>
                        <th colspan="1" class="text-center">FALTAS</th>
                        <th colspan="1" class="text-center">CALIFICACIÓN</th>
                        <th colspan="1" class="text-center">FALTAS</th>
                        <th colspan="1" class="text-center">CALIFICACIÓN</th>
                        <th colspan="1" class="text-center">FALTAS</th>
                        <th colspan="1" class="text-center">NÚMERO</th>
                        <th colspan="1" class="text-center">LETRAS</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $inscritosCurso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <form action="<?php echo e(route('actualizarCalificacion', $data->idAlumnoCursoNota)); ?>" method="post">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <td class="text-center"> <?php echo e($data->idAlumno); ?></td>
                                <td><?php echo e($data->apePaterno . ' ' . $data->apeMaterno . ' ' . $data->nombre); ?></td>

                                <td>
                                    <?php if($data->nota1 == null): ?>
                                        <input min="5" max="10" id="nota1" type="text" maxlength="2" name="nota1"
                                            value="<?php echo e($data->nota1); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <?php if($data->nota1 <= '5'): ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:red"><?php echo e($data->nota1); ?></label>
                                        <?php else: ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:black"><?php echo e($data->nota1); ?></label>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($data->falta1 == null): ?>
                                        <input id="falta1" type="text" maxlength="1" name="falta1"
                                            value="<?php echo e($data->falta1); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <label type="text" class="text-center m-auto d-block"
                                            style="border: none; color:black"><?php echo e($data->falta1); ?></label>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($data->nota2 == null && $data->nota1 != null): ?>
                                        <input id="nota2" type="text" maxlength="2" name="nota2"
                                            value="<?php echo e($data->nota2); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <?php if($data->nota2 <= '5'): ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:red"><?php echo e($data->nota2); ?></label>
                                        <?php else: ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:black"><?php echo e($data->nota2); ?></label>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($data->falta2 == null && $data->falta1 != null): ?>
                                        <input id="falta2" type="text" maxlength="1" name="falta2"
                                            value="<?php echo e($data->falta2); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <label type="text" class="text-center m-auto d-block"
                                            style="border: none; color:black"><?php echo e($data->falta2); ?></label>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($data->nota3 == null && $data->nota2 != null): ?>
                                        <input id="nota3" type="text" maxlength="2" name="nota3"
                                            value="<?php echo e($data->nota3); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <?php if($data->nota3 <= '5'): ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:red"><?php echo e($data->nota3); ?></label>
                                        <?php else: ?>
                                            <label type="text" class="text-center m-auto d-block"
                                                style="border: none; color:black"><?php echo e($data->nota3); ?></label>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?php if($data->falta3 == null && $data->falta2 != null): ?>
                                        <input id="falta3" type="text" maxlength="1" name="falta3"
                                            value="<?php echo e($data->falta3); ?>" size="3" class="text-center m-auto d-block"
                                            onkeypress="return soloNumeros(event)" style="border: none">
                                    <?php else: ?>
                                        <label type="text" class="text-center m-auto d-block"><?php echo e($data->falta3); ?></label>
                                    <?php endif; ?>

                                </td>

                                <td><?php if($data->notaFinal <= '5'): ?>
                                    <label class="text-center m-auto d-block" style="color:red"><?php echo e($data->notaFinal); ?></label>
                                <?php else: ?>
                                <label class="text-center m-auto d-block"><?php echo e($data->notaFinal); ?></label>
                                <?php endif; ?>
                                    
                                </td>
                                <td>
                                    <label class="text-center m-auto d-block"><?php echo e($data->letra); ?></label>
                                </td>
                                <td class="text-center">
                                    <?php if($valor == '1' && $data->notaFinal == null): ?>
                                        <input type="submit" class="btn btn-success" name="btn<?php echo e($data->idUserCourse); ?>"
                                            value="Calificar">
                                    <?php else: ?>
                                        <button disabled type="button" class="btn btn-success" name="">Calificar</button>
                                    <?php endif; ?>
                                </td>
                            </form>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src=<?php echo e(asset('js/dataTable.js')); ?>></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripcionesSinGoogle\resources\views/profiles/teacher/inscritosCurso.blade.php ENDPATH**/ ?>