

<?php $__env->startSection('contenido'); ?>

<?php echo e($user_found); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inscripciones\resources\views/homeStudent.blade.php ENDPATH**/ ?>